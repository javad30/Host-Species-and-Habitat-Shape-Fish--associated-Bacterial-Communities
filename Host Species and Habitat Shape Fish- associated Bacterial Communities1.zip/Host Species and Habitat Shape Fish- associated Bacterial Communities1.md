# Host Species and Habitat Shape Fish- associated Bacterial Communities: Phylosymbiosis between Fish and their Microbiome 
#### By Javad Sadeghi, University of British Columbia, Canada. Email:Javad.sadeghi@ubc.ca


##### Calculate differences in alpha diversity (species richness and evenness (Shannon entropy, Chao1, PD)) among the different sample types (gut vs water, as well as skin vs water samples) at all locations combined as well as within each location separately were tested using the Kruskal-Wallis (KW) rank test followed by a post hoc Dunn test with Bonferroni corrected P values 



```R
Alpha_Diversity_indices= read.delim("Alpha_Diversity_indices.txt", sep = "\t" , row.names = 1)


library(dunn.test)
library(RColorBrewer)


hist(Alpha_Diversity_indices$faith_pd)
hist(Alpha_Diversity_indices$chao1)
hist(Alpha_Diversity_indices$shannon_entropy)

qqnorm(Alpha_Diversity_indices$faith_pd)
qqline(Alpha_Diversity_indices$faith_pd)

qqnorm(Alpha_Diversity_indices$chao1)
qqline(Alpha_Diversity_indices$chao1)

qqnorm(Alpha_Diversity_indices$shannon_entropy)
qqline(Alpha_Diversity_indices$shannon_entropy)


shapiro.test(Alpha_Diversity_indices$shannon_entropy)
shapiro.test(Alpha_Diversity_indices$faith_pd)
shapiro.test(Alpha_Diversity_indices$chao1)


kruskal.test(chao1 ~ sample_type, data = Alpha_Diversity_indices)


kruskal.test(shannon_entropy ~ sample_type, data = Alpha_Diversity_indices)


kruskal.test(faith_pd ~ sample_type, data = Alpha_Diversity_indices)



continuous1 <- Alpha_Diversity_indices$shannon_entropy
continuous2 <- Alpha_Diversity_indices$faith_pd
continuous3 <- Alpha_Diversity_indices$chao1
category <- Alpha_Diversity_indices$sample_type


library(RColorBrewer)

par(mfrow = c(1, 3))


colors <- c("#E6B8AF", "#C5E0B4", "#B7CCE4")

boxplot(continuous1 ~ category, main = "Shannon entropy",  col = colors)


boxplot(continuous2 ~ category, main = "Faith PD",  col = colors)

boxplot(continuous3 ~ category, main = "chao1",  col = colors)




```


    
![png](output_2_0.png)
    



    
![png](output_2_1.png)
    



    
![png](output_2_2.png)
    



    
![png](output_2_3.png)
    



    
![png](output_2_4.png)
    



    
    	Shapiro-Wilk normality test
    
    data:  Alpha_Diversity_indices$shannon_entropy
    W = 0.9887, p-value = 8.879e-05
    



    
    	Shapiro-Wilk normality test
    
    data:  Alpha_Diversity_indices$faith_pd
    W = 0.80128, p-value < 2.2e-16
    



    
    	Shapiro-Wilk normality test
    
    data:  Alpha_Diversity_indices$chao1
    W = 0.72604, p-value < 2.2e-16
    



    
    	Kruskal-Wallis rank sum test
    
    data:  chao1 by sample_type
    Kruskal-Wallis chi-squared = 63.559, df = 2, p-value = 1.579e-14
    



    
    	Kruskal-Wallis rank sum test
    
    data:  shannon_entropy by sample_type
    Kruskal-Wallis chi-squared = 81.47, df = 2, p-value < 2.2e-16
    



    
    	Kruskal-Wallis rank sum test
    
    data:  faith_pd by sample_type
    Kruskal-Wallis chi-squared = 74.528, df = 2, p-value < 2.2e-16
    



    
![png](output_2_11.png)
    



    
![png](output_2_12.png)
    


#### Taxonomic composition of the microbiota of gut and skin samples from seventeen fish species sampled at three locations (Detroit River, Lake Erie, and Lake Ontario) were visualized using stacked barplots of the relative abundance of the bacteria at the family level using phyloseq and ggplot2packages 
#Importing all data (gut, skin, water)



```R

library("dplyr")
library("readxl")             
library("tibble")       
library(cowplot)
library(picante)
library(tidyverse)
library("ggplot2") 
library(phyloseq)
library(DESeq2)
library(vegan)
library(devtools)
library(dendextend)
library(rms)
library("gridExtra")

otu_mat <- as.matrix(read.table("Table.txt", header=TRUE, sep = "\t",
                                row.names = 1,
                                
                                
                                as.is=TRUE))


tax_mat <- as.matrix(read.table("Tax1.txt", header=TRUE, sep = "\t",
                                row.names = 1,
                                
                                
                                as.is=TRUE))

samples_df= read.delim("metadata630.txt", sep = "\t" , row.names = 1)


tree <- read.tree("tree.nwk")

tree




OTU = otu_table(otu_mat, taxa_are_rows = TRUE)
TAX = tax_table(tax_mat)
samples = sample_data(samples_df)

ps  <- phyloseq(OTU, TAX, samples, tree)

ps_Gut <- subset_samples(ps, sample_type=="Gut")

ps_Skin <- subset_samples(ps, sample_type=="Skin")

ps_Water <- subset_samples(ps, sample_type=="water")



sort(phyloseq::sample_sums(ps_Gut)) 

(ps_Gut <- phyloseq::prune_taxa(phyloseq::taxa_sums(ps_Gut) > 0, ps_Gut)) 


table(phyloseq::tax_table(ps_Gut)[, "Family"])

ps_Gut_Family <- phyloseq::tax_glom(ps_Gut, "Family")

tables <- phyloseq::otu_table(ps_Gut_Family)
#write.csv(tables, file = "tableps_Gut.csv")

phyloseq::taxa_names(ps_Gut_Family) <- phyloseq::tax_table(ps_Gut_Family)[, "Family"]


tables1 <- phyloseq::otu_table(ps_Gut_Family)
#write.csv(tables1, file = "tables1.csv")

ps_Gut_Family_rel_abund = phyloseq::transform_sample_counts(ps_Gut_Family, function(x){x / sum(x)}*100)




tables_relative <- phyloseq::otu_table(ps_Gut_Family_rel_abund)
##write.csv(tables_relative, file = "tables_relative.csv")

y4_Gut <- psmelt(ps_Gut_Family_rel_abund) 
y4_Gut$Family <- as.character(y4_Gut$Family) 
y4_Gut$Family[y4_Gut$Abundance < 10]  <- "Family < 10% abund."
###write.csv(y4_Gut, file = "y4_Gut_tables_relative.csv")

y4_Gut$Locations <- gsub("Lake_Ontario", "LO", y4_Gut$Locations)
y4_Gut$Locations <- gsub("Lake_Erie", "LE", y4_Gut$Locations)
y4_Gut$Locations <- gsub("Detroit_River", "DR", y4_Gut$Locations)
y4_Gut$Fishname <- gsub("Alewife", "Alewife", y4_Gut$Fishname)
y4_Gut$Fishname <- gsub("Blacknose_shiner", "Blacknose Shiner", y4_Gut$Fishname)
y4_Gut$Fishname <- gsub("Brook_silverside_fish", "Brook Silverside", y4_Gut$Fishname)
y4_Gut$Fishname <- gsub("Brown_Trout", "Brown Trout", y4_Gut$Fishname)
y4_Gut$Fishname <- gsub("Emerald", "Emerald", y4_Gut$Fishname)
y4_Gut$Fishname <- gsub("FD", "Freshwater Drum", y4_Gut$Fishname)
y4_Gut$Fishname <- gsub("Freshwater_drum", "Freshwater Drum", y4_Gut$Fishname)
y4_Gut$Fishname <- gsub("Freshwater_Drum", "Freshwater Drum", y4_Gut$Fishname)
y4_Gut$Fishname <- gsub("Gizzard_Shad", "American Gizzard Shad", y4_Gut$Fishname)
y4_Gut$Fishname <- gsub("Gizzard_shad", "American Gizzard Shad", y4_Gut$Fishname)
y4_Gut$Fishname <- gsub("Rock_Bass", "Rock Bass", y4_Gut$Fishname)
y4_Gut$Fishname <- gsub("Lake_Trout", "Lake Trout", y4_Gut$Fishname)
y4_Gut$Fishname <- gsub("Round_Goby", "Round Goby", y4_Gut$Fishname)
y4_Gut$Fishname <- gsub("Spotfin_shiner", "Spotfin Shiner", y4_Gut$Fishname)
y4_Gut$Fishname <- gsub("White_Bass", "White Bass", y4_Gut$Fishname)
y4_Gut$Fishname <- gsub("White_Perch", "White Perch", y4_Gut$Fishname)
y4_Gut$Fishname <- gsub("White_Sucker", "White Sucker", y4_Gut$Fishname)
y4_Gut$Fishname <- gsub("Yellow_perch", "Yellow Perch", y4_Gut$Fishname)
y4_Gut$Fishname <- gsub("Yellow_Perch", "Yellow Perch", y4_Gut$Fishname)

library(ggplot2)
p <- ggplot(data = y4_Gut, aes(x = Sample, y = Abundance, fill = Family)) +
  geom_bar(stat = "identity", position = "stack") +
  labs(x = "", y = "Relative Abundance %") +
  facet_wrap(~ Fishname + Locations, scales = "free") +
  theme(panel.background = element_blank(),
        axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        legend.text = element_text(size = 12, face = "bold.italic"),
        legend.position = "bottom",
        strip.text.x = element_text(size = 12, color = "Black", face = "bold"),
        strip.text.y = element_text(size = 12, color = "Black", face = "bold")) +
  guides(fill = guide_legend(nrow = 8, title = NULL))

p
```


    
    Phylogenetic tree with 57222 tips and 55553 internal nodes.
    
    Tip labels:
      6b48898668f85afc86134d4081e93add, ea8f282a002c08288850c15b50246b51, d0f71d7f641e1d656b93d50ba9698a35, b3ea6ba1eec5d05856b0eb56b919d316, 2670a6ee05819fe7c3102c3656b1767d, 3813ef9318df7308e1f1562fba9aa719, ...
    Node labels:
      root, 0.953, 0.885, 0.391, 0.000, 0.855, ...
    
    Rooted; includes branch lengths.



<style>
.dl-inline {width: auto; margin:0; padding: 0}
.dl-inline>dt, .dl-inline>dd {float: none; width: auto; display: inline-block}
.dl-inline>dt::after {content: ":\0020"; padding-right: .5ex}
.dl-inline>dt:not(:first-of-type) {padding-left: .5ex}
</style><dl class=dl-inline><dt>G80</dt><dd>1041</dd><dt>G350</dt><dd>1111</dd><dt>G244</dt><dd>1388</dd><dt>G48</dt><dd>1406</dd><dt>G238</dt><dd>1961</dd><dt>G298</dt><dd>2063</dd><dt>G46</dt><dd>2272</dd><dt>G150</dt><dd>2582</dd><dt>G31</dt><dd>2716</dd><dt>G151</dt><dd>3076</dd><dt>G47</dt><dd>3113</dd><dt>G142</dt><dd>3447</dd><dt>G149</dt><dd>3618</dd><dt>G119</dt><dd>3773</dd><dt>G246</dt><dd>3819</dd><dt>G53</dt><dd>3842</dd><dt>G33</dt><dd>4096</dd><dt>G43</dt><dd>4116</dd><dt>G97</dt><dd>4269</dd><dt>G45</dt><dd>4313</dd><dt>G12</dt><dd>4349</dd><dt>G303</dt><dd>4416</dd><dt>G109</dt><dd>4424</dd><dt>G27</dt><dd>4545</dd><dt>G19</dt><dd>4809</dd><dt>G199</dt><dd>4810</dd><dt>G144</dt><dd>4856</dd><dt>G37</dt><dd>4860</dd><dt>G17</dt><dd>4922</dd><dt>G205</dt><dd>5006</dd><dt>G353</dt><dd>5193</dd><dt>G127</dt><dd>5214</dd><dt>G49</dt><dd>5235</dd><dt>G312</dt><dd>5681</dd><dt>G308</dt><dd>5723</dd><dt>G13</dt><dd>5740</dd><dt>G30</dt><dd>5797</dd><dt>G158</dt><dd>5951</dd><dt>G32</dt><dd>6032</dd><dt>G234</dt><dd>6064</dd><dt>G56</dt><dd>6064</dd><dt>G57</dt><dd>6104</dd><dt>G307</dt><dd>6425</dd><dt>G67</dt><dd>6544</dd><dt>G157</dt><dd>6605</dd><dt>G232</dt><dd>6652</dd><dt>G204</dt><dd>6798</dd><dt>G297</dt><dd>6859</dd><dt>G20</dt><dd>6862</dd><dt>G132</dt><dd>6994</dd><dt>G179</dt><dd>7046</dd><dt>G76</dt><dd>7119</dd><dt>G86</dt><dd>7281</dd><dt>G110</dt><dd>7290</dd><dt>G252</dt><dd>7404</dd><dt>G250</dt><dd>7407</dd><dt>G21</dt><dd>7508</dd><dt>G351</dt><dd>7577</dd><dt>G354</dt><dd>7629</dd><dt>G254</dt><dd>7686</dd><dt>G324</dt><dd>7859</dd><dt>G319</dt><dd>7939</dd><dt>G22</dt><dd>8105</dd><dt>G89</dt><dd>8171</dd><dt>G51</dt><dd>8189</dd><dt>G61</dt><dd>8285</dd><dt>G35</dt><dd>8345</dd><dt>G300</dt><dd>8356</dd><dt>G54</dt><dd>8494</dd><dt>G125</dt><dd>8688</dd><dt>G247</dt><dd>8739</dd><dt>G245</dt><dd>8744</dd><dt>G155</dt><dd>8844</dd><dt>G326</dt><dd>8922</dd><dt>G77</dt><dd>9006</dd><dt>G40</dt><dd>9035</dd><dt>G251</dt><dd>9052</dd><dt>G66</dt><dd>9055</dd><dt>G79</dt><dd>9136</dd><dt>G325</dt><dd>9142</dd><dt>G228</dt><dd>9187</dd><dt>G231</dt><dd>9230</dd><dt>G218</dt><dd>9267</dd><dt>G321</dt><dd>9447</dd><dt>G314</dt><dd>9476</dd><dt>G29</dt><dd>9515</dd><dt>G8</dt><dd>9582</dd><dt>G11</dt><dd>9779</dd><dt>G343</dt><dd>10020</dd><dt>G26</dt><dd>10066</dd><dt>G328</dt><dd>10102</dd><dt>G83</dt><dd>10133</dd><dt>G220</dt><dd>10173</dd><dt>G65</dt><dd>10246</dd><dt>G309</dt><dd>10498</dd><dt>G111</dt><dd>10657</dd><dt>G25</dt><dd>10779</dd><dt>G357</dt><dd>10791</dd><dt>G165</dt><dd>10806</dd><dt>G10</dt><dd>10831</dd><dt>G73</dt><dd>10897</dd><dt>G327</dt><dd>11014</dd><dt>G211</dt><dd>11226</dd><dt>G36</dt><dd>11460</dd><dt>G34</dt><dd>11475</dd><dt>G306</dt><dd>11488</dd><dt>G112</dt><dd>11500</dd><dt>G52</dt><dd>11562</dd><dt>G182</dt><dd>11676</dd><dt>G340</dt><dd>11759</dd><dt>G78</dt><dd>11898</dd><dt>G69</dt><dd>12170</dd><dt>G342</dt><dd>12260</dd><dt>G50</dt><dd>12595</dd><dt>G323</dt><dd>12674</dd><dt>G24</dt><dd>12734</dd><dt>G310</dt><dd>12796</dd><dt>G84</dt><dd>12823</dd><dt>G337</dt><dd>13114</dd><dt>G195</dt><dd>13247</dd><dt>G338</dt><dd>13363</dd><dt>G164</dt><dd>13430</dd><dt>G55</dt><dd>13498</dd><dt>G90</dt><dd>13684</dd><dt>G291</dt><dd>13891</dd><dt>G166</dt><dd>13961</dd><dt>G216</dt><dd>14029</dd><dt>G161</dt><dd>14203</dd><dt>G58</dt><dd>14271</dd><dt>G236</dt><dd>14483</dd><dt>G99</dt><dd>14646</dd><dt>G2</dt><dd>14718</dd><dt>G241</dt><dd>14773</dd><dt>G242</dt><dd>14982</dd><dt>G243</dt><dd>15184</dd><dt>G249</dt><dd>15261</dd><dt>G194</dt><dd>15373</dd><dt>G75</dt><dd>15505</dd><dt>G7</dt><dd>15507</dd><dt>G18</dt><dd>15704</dd><dt>G107</dt><dd>15764</dd><dt>G81</dt><dd>15848</dd><dt>G14</dt><dd>15852</dd><dt>G137</dt><dd>15933</dd><dt>G181</dt><dd>15966</dd><dt>G347</dt><dd>16245</dd><dt>G237</dt><dd>16282</dd><dt>G41</dt><dd>16322</dd><dt>G227</dt><dd>16440</dd><dt>G226</dt><dd>16701</dd><dt>G15</dt><dd>16720</dd><dt>G72</dt><dd>16762</dd><dt>G219</dt><dd>17011</dd><dt>G184</dt><dd>17217</dd><dt>G301</dt><dd>17398</dd><dt>G23</dt><dd>17694</dd><dt>G203</dt><dd>17819</dd><dt>G201</dt><dd>18042</dd><dt>G129</dt><dd>18066</dd><dt>G196</dt><dd>18185</dd><dt>G1</dt><dd>18282</dd><dt>G183</dt><dd>18427</dd><dt>G336</dt><dd>18459</dd><dt>G147</dt><dd>18562</dd><dt>G102</dt><dd>18576</dd><dt>G355</dt><dd>18708</dd><dt>G87</dt><dd>18716</dd><dt>G108</dt><dd>18765</dd><dt>G123</dt><dd>18908</dd><dt>G3</dt><dd>19000</dd><dt>G197</dt><dd>19085</dd><dt>G172</dt><dd>19230</dd><dt>G156</dt><dd>19369</dd><dt>G128</dt><dd>19464</dd><dt>G299</dt><dd>19472</dd><dt>G148</dt><dd>19632</dd><dt>G317</dt><dd>20001</dd><dt>G305</dt><dd>20017</dd><dt>G39</dt><dd>20040</dd><dt>G68</dt><dd>20057</dd><dt>G294</dt><dd>20154</dd><dt>G91</dt><dd>20207</dd><dt>G16</dt><dd>20319</dd><dt>G358</dt><dd>20362</dd><dt>G6</dt><dd>20537</dd><dt>G64</dt><dd>20558</dd><dt>G356</dt><dd>20594</dd><dt>G210</dt><dd>20624</dd><dt>G235</dt><dd>21183</dd><dt>G339</dt><dd>21280</dd><dt>G202</dt><dd>21461</dd><dt>G222</dt><dd>22098</dd><dt>G302</dt><dd>22325</dd><dt>G133</dt><dd>22380</dd><dt>G124</dt><dd>22541</dd><dt>G295</dt><dd>22823</dd><dt>G71</dt><dd>22872</dd><dt>G167</dt><dd>24000</dd><dt>G345</dt><dd>24019</dd><dt>G318</dt><dd>24121</dd><dt>G213</dt><dd>24233</dd><dt>G359</dt><dd>24269</dd><dt>G98</dt><dd>24726</dd><dt>G333</dt><dd>25125</dd><dt>G209</dt><dd>25360</dd><dt>G290</dt><dd>25463</dd><dt>G62</dt><dd>25510</dd><dt>G255</dt><dd>25620</dd><dt>G320</dt><dd>25906</dd><dt>G38</dt><dd>26403</dd><dt>G44</dt><dd>26435</dd><dt>G360</dt><dd>26589</dd><dt>G130</dt><dd>26770</dd><dt>G292</dt><dd>26844</dd><dt>G248</dt><dd>27277</dd><dt>G349</dt><dd>28353</dd><dt>G331</dt><dd>28664</dd><dt>G207</dt><dd>28894</dd><dt>G59</dt><dd>29057</dd><dt>G152</dt><dd>29161</dd><dt>G240</dt><dd>29199</dd><dt>G329</dt><dd>29767</dd><dt>G313</dt><dd>29798</dd><dt>G178</dt><dd>30069</dd><dt>G146</dt><dd>31138</dd><dt>G140</dt><dd>31573</dd><dt>G334</dt><dd>31927</dd><dt>G154</dt><dd>31995</dd><dt>G138</dt><dd>32611</dd><dt>G42</dt><dd>33576</dd><dt>G311</dt><dd>33608</dd><dt>G70</dt><dd>34669</dd><dt>G74</dt><dd>35075</dd><dt>G163</dt><dd>35208</dd><dt>G4</dt><dd>35221</dd><dt>G296</dt><dd>35781</dd><dt>G5</dt><dd>36332</dd><dt>G217</dt><dd>36532</dd><dt>G9</dt><dd>36778</dd><dt>G174</dt><dd>37648</dd><dt>G134</dt><dd>38062</dd><dt>G60</dt><dd>38157</dd><dt>G221</dt><dd>38415</dd><dt>G168</dt><dd>38690</dd><dt>G332</dt><dd>39537</dd><dt>G104</dt><dd>39986</dd><dt>G82</dt><dd>40198</dd><dt>G198</dt><dd>40679</dd><dt>G215</dt><dd>41225</dd><dt>G159</dt><dd>41589</dd><dt>G304</dt><dd>42389</dd><dt>G117</dt><dd>43040</dd><dt>G214</dt><dd>43066</dd><dt>G200</dt><dd>43227</dd><dt>G185</dt><dd>43756</dd><dt>G177</dt><dd>44141</dd><dt>G322</dt><dd>44420</dd><dt>G103</dt><dd>44975</dd><dt>G173</dt><dd>46317</dd><dt>G120</dt><dd>46652</dd><dt>G162</dt><dd>47274</dd><dt>G256</dt><dd>47873</dd><dt>G169</dt><dd>47997</dd><dt>G180</dt><dd>49238</dd><dt>G229</dt><dd>49515</dd><dt>G208</dt><dd>50437</dd><dt>G115</dt><dd>51221</dd><dt>G170</dt><dd>51409</dd><dt>G139</dt><dd>52367</dd><dt>G289</dt><dd>52627</dd><dt>G315</dt><dd>52632</dd><dt>G175</dt><dd>53198</dd><dt>G145</dt><dd>53463</dd><dt>G126</dt><dd>54144</dd><dt>G330</dt><dd>54918</dd><dt>G122</dt><dd>55068</dd><dt>G160</dt><dd>56281</dd><dt>G293</dt><dd>57476</dd><dt>G121</dt><dd>57833</dd><dt>G88</dt><dd>57847</dd><dt>G230</dt><dd>57897</dd><dt>G224</dt><dd>59731</dd><dt>G131</dt><dd>61264</dd><dt>G223</dt><dd>63487</dd><dt>G335</dt><dd>65179</dd><dt>G63</dt><dd>66774</dd><dt>G100</dt><dd>69274</dd><dt>G346</dt><dd>70682</dd><dt>G135</dt><dd>72151</dd><dt>G153</dt><dd>73694</dd><dt>G113</dt><dd>74051</dd><dt>G114</dt><dd>74957</dd><dt>G176</dt><dd>77687</dd><dt>G225</dt><dd>83118</dd><dt>G348</dt><dd>87558</dd><dt>G28</dt><dd>103389</dd></dl>




    phyloseq-class experiment-level object
    otu_table()   OTU Table:         [ 3374 taxa and 296 samples ]
    sample_data() Sample Data:       [ 296 samples by 9 sample variables ]
    tax_table()   Taxonomy Table:    [ 3374 taxa by 5 taxonomic ranks ]
    phy_tree()    Phylogenetic Tree: [ 3374 tips and 3155 internal nodes ]



    
             Absconditabacteriales_(SR1)                     Acetobacteraceae 
                                       1                                   35 
                      Acidaminococcaceae                     Actinomycetaceae 
                                       4                                    2 
                           Aerococcaceae                       Aeromonadaceae 
                                       1                                   50 
                         Akkermansiaceae                              AKYH767 
                                       1                                    1 
                          Alcaligenaceae                     Alteromonadaceae 
                                      11                                   22 
                         Anaerolineaceae                      Anaplasmataceae 
                                      10                                    5 
                         Arcobacteraceae                       Arenicellaceae 
                                       4                                    4 
                                  B1-7BS                           Babeliales 
                                      10                                   12 
                             Bacillaceae                   Bacteriovoracaceae 
                                      18                                   15 
                          Bacteroidaceae              Bacteroidetes_vadinHA17 
                                       5                                    1 
                         Barnesiellaceae                   Bdellovibrionaceae 
                                       8                                    7 
                        Beijerinckiaceae                       Berkelbacteria 
                                      53                                    1 
                       Blastocatellaceae                       Bradymonadales 
                                       6                                    1 
                        Brevibacillaceae                    Brevibacteriaceae 
                                       3                                    3 
                         Brevinemataceae                      Bryobacteraceae 
                                       4                                    2 
                        Burkholderiaceae                       Caldilineaceae 
                                      21                                   56 
                        Caloramatoraceae             Candidatus_Adlerbacteria 
                                       1                                    4 
               Candidatus_Kaiserbacteria                    Carnobacteriaceae 
                                       1                                    4 
                        Caulobacteraceae                    Cellulomonadaceae 
                                      16                                    1 
                        Cellvibrionaceae                   Chitinibacteraceae 
                                       1                                   15 
                        Chitinophagaceae          Chlamydiales_Incertae_Sedis 
                                      33                                    2 
                             Chloroplast                  Christensenellaceae 
                                      53                                   10 
                      Chromobacteriaceae                  Chthoniobacteraceae 
                                      17                                   37 
                               Clade_III                   Clostridia_UCG-014 
                                       2                                    1 
                          Clostridiaceae                       Comamonadaceae 
                                     128                                  111 
                      Corynebacteriaceae                         Coxiellaceae 
                                       7                                    1 
                                    CPR2                    Crocinitomicaceae 
                                      11                                    4 
                          Cryomorphaceae                         Cyanobiaceae 
                                       2                                   23 
                       Cyclobacteriaceae                        Cytophagaceae 
                                      15                                    1 
                       Defluviicoccaceae                       Deinococcaceae 
                                       2                                    7 
                        Desulfarculaceae                  Desulfatiglandaceae 
                                       2                                    1 
                    Desulfitobacteriales                     Desulfobaccaceae 
                                       1                                    9 
                        Desulfocapsaceae                    Desulfomonilaceae 
                                       7                                    6 
                      Desulfosarcinaceae                  Desulfovibrionaceae 
                                       3                                    6 
                                  DEV007                          Devosiaceae 
                                       2                                    5 
                             Dietziaceae                  Diplorickettsiaceae 
                                       1                                   12 
                       Dysgonomonadaceae                   Enterobacteriaceae 
                                       3                                   69 
                         Enterococcaceae                           env.OPS_17 
                                       3                                    2 
                             Erwiniaceae                  Erysipelotrichaceae 
                                       3                                   13 
                       Exiguobacteraceae                    Ferrovibrionaceae 
                                       5                                    1 
                       Fimbriimonadaceae                    Flavobacteriaceae 
                                       1                                   16 
                             Fokiniaceae                           Frankiales 
                                       5                                    3 
                        Fusobacteriaceae                          Gemellaceae 
                                      40                                    1 
                             Gemmataceae                    Gemmatimonadaceae 
                                      26                                    5 
                          Geobacteraceae                       Gloeocapsaceae 
                                       2                                    2 
                              Hafniaceae                           Halieaceae 
                                       2                                    5 
                          Halomonadaceae                   Herpetosiphonaceae 
                                      16                                    1 
                           Holosporaceae               Hungateiclostridiaceae 
                                      11                                    3 
                      Hydrogenedensaceae                   Hydrogenophilaceae 
                                       2                                    1 
                       Hyphomicrobiaceae                      Hyphomonadaceae 
                                      17                                    8 
                               Iamiaceae                   Ilumatobacteraceae 
                                       9                                   23 
                               IMCC26256                       Isosphaeraceae 
                                      18                                   40 
                            JG30-KF-CM45                          Kaistiaceae 
                                       3                                    1 
                         Kapabacteriales                               KD4-96 
                                       2                                   17 
                               Labraceae                      Lachnospiraceae 
                                       2                                   57 
                        Lactobacillaceae                              LD1-PB3 
                                       4                                    1 
                          Legionellaceae                     Leuconostocaceae 
                                      57                                    1 
                         Limnotrichaceae                         Listeriaceae 
                                       1                                    1 
                                    LWQ8                            MB-A2-108 
                                       1                                   10 
                       Methanoregulaceae                 Methylacidiphilaceae 
                                       1                                    5 
                        Methylococcaceae                   Methyloligellaceae 
                                      12                                    2 
                       Methylomonadaceae                     Methylophilaceae 
                                       9                                    6 
                       Microbacteriaceae                       Micrococcaceae 
                                      53                                   16 
                          Microcystaceae                      Microscillaceae 
                                      12                                    1 
                         Microtrichaceae                         Mitochondria 
                                       9                                    6 
                                 mle1-27                        Moraxellaceae 
                                       1                                   41 
                          Morganellaceae              MWH-UniP1_aquatic_group 
                                       5                                    2 
                        Mycobacteriaceae                     Mycoplasmataceae 
                                       8                                   46 
                                   NB1-j                        Neisseriaceae 
                                       2                                    2 
                       Nitrosomonadaceae                       Nitrospiraceae 
                                       3                                    1 
                         Nocardioidaceae                      Nodosilineaceae 
                                       2                                    1 
                             Nostocaceae                 NS11-12_marine_group 
                                       1                                    2 
                        NS9_marine_group                        Oligoflexales 
                                       3                                    2 
                                   OM190                       Omnitrophaceae 
                                       3                                    1 
                                   OPB41                     Oxalobacteraceae 
                                       6                                   13 
                               P9X2b3D02                     Paenibacillaceae 
                                       3                                    7 
                       Paludibacteraceae                 Paracaedibacteraceae 
                                       1                                    2 
                       Parachlamydiaceae                      Pasteurellaceae 
                                       4                                    5 
                                    PB19                      Pedosphaeraceae 
                                       1                                    7 
                                   PeM15                Peptostreptococcaceae 
                                      24                                   55 
     Peptostreptococcales-Tissierellales                        Phormidiaceae 
                                       4                                    5 
                        Phycisphaeraceae                        Pirellulaceae 
                                       2                                  260 
                            Pla1_lineage                       Planococcaceae 
                                       1                                    7 
                    Pleomorphomonadaceae                Promicromonosporaceae 
                                       1                                    1 
                    Propionibacteriaceae                    Pseudanabaenaceae 
                                       7                                    2 
                        Pseudomonadaceae                          RBG-13-54-9 
                                      50                                   10 
                          Reyranellaceae                         Rhizobiaceae 
                                      10                                   41 
              Rhizobiales_Incertae_Sedis                   Rhodanobacteraceae 
                                      41                                    8 
                        Rhodobacteraceae                       Rhodocyclaceae 
                                     111                                   13 
                       Rhodospirillaceae                       Rickettsiaceae 
                                       2                                    8 
                           Rikenellaceae                       Roseiflexaceae 
                                       1                                    2 
                       Rubinisphaeraceae                       Rubritaleaceae 
                                      33                                    4 
                         Ruminococcaceae                   Saccharimonadaceae 
                                      12                                    3 
                       Saccharimonadales                 Saccharospirillaceae 
                                      55                                    1 
                         Sandaracinaceae                    Sanguibacteraceae 
                                       1                                    1 
                          Saprospiraceae         SAR324_clade(Marine_group_B) 
                                       2                                    1 
                                 SC-I-84                      Schlesneriaceae 
                                      33                                   15 
                       Sericytochromatia                       Shewanellaceae 
                                       1                                   31 
                       Silvanigrellaceae                         Simkaniaceae 
                                       6                                    1 
                                  SJA-15                               SJA-28 
                                      11                                    4 
                       SL56_marine_group                               SM2D12 
                                       3                                    1 
                     Sphingobacteriaceae                    Sphingomonadaceae 
                                      24                                   53 
                         Spirochaetaceae                        Spirosomaceae 
                                       2                                    9 
                         Sporichthyaceae                        Sporomusaceae 
                                      19                                    1 
                                ST-12K33                    Staphylococcaceae 
                                       2                                   20 
                     Steroidobacteraceae                     Streptococcaceae 
                                      15                                   27 
                             Subgroup_17                          Subgroup_22 
                                      18                                    1 
                     Sulfurospirillaceae                        Sumerlaeaceae 
                                       1                                    1 
                          Sutterellaceae                              Sva0485 
                                       8                                    1 
                          Synergistaceae                 Syntrophobacteraceae 
                                      10                                    6 
                                   SZB30                                 TA06 
                                       3                                    2 
                          Tannerellaceae                    Terrimicrobiaceae 
                                       7                                    9 
                          Thermicanaceae                              TRA3-20 
                                       1                                    2 
                                UBA12409                            vadinHA49 
                                       1                                    1 
                           Vagococcaceae                      Veillonellaceae 
                                       1                                    5 
                          Vermiphilaceae                  Verrucomicrobiaceae 
                                       2                                   38 
                            Vibrionaceae                  Vicinamibacteraceae 
                                       7                                   26 
                                WCHB1-41                             WCHB1-81 
                                       8                                    6 
                       WD2101_soil_group                        Weeksellaceae 
                                       2                                   22 
                    Williamwhitmaniaceae                Wohlfahrtiimonadaceae 
                                       1                                    6 
                       Xanthobacteraceae                     Xanthomonadaceae 
                                      19                                   39 
                  Xiphinematobacteraceae                         Yersiniaceae 
                                       1                                    1 



    
![png](output_4_4.png)
    


###### Testing Skin samples


```R

ps_Skin <- subset_samples(ps, sample_type=="Skin")

sort(phyloseq::sample_sums(ps_Skin)) 


(ps_Skin <- phyloseq::prune_taxa(phyloseq::taxa_sums(ps_Skin) > 0, ps_Skin)) 


table(phyloseq::tax_table(ps_Skin)[, "Family"])


ps_Skin_Family <- phyloseq::tax_glom(ps_Skin, "Family")

tables_ps_Skin <- phyloseq::otu_table(ps_Skin_Family)
#write.csv(tables_ps_Skin, file = "tableps_Skin.csv")

phyloseq::taxa_names(ps_Skin_Family) <- phyloseq::tax_table(ps_Skin_Family)[, "Family"]


tables1_ps_Skin <- phyloseq::otu_table(ps_Skin_Family)
#write.csv(tables1_ps_Skin, file = "tables1_ps_Skin.csv")


ps_Skin_Family_rel_abund = phyloseq::transform_sample_counts(ps_Skin_Family, function(x){x / sum(x)}*100)




tables_relative_ps_Skin <- phyloseq::otu_table(ps_Skin_Family_rel_abund)
#write.csv(tables_relative_ps_Skin, file = "tables_relative_ps_Skin.csv")



y4_Skin <- psmelt(ps_Skin_Family_rel_abund) 
y4_Skin$Family <- as.character(y4_Skin$Family) 
y4_Skin$Family[y4_Skin$Abundance < 10] <- "Family < 10% abund."
#write.csv(y4_Skin, file = "y4_Skin_tables_relative.csv")

y4_Skin$Locations <- gsub("Lake_Ontario", "LO", y4_Skin$Locations)
y4_Skin$Locations <- gsub("Lake_Erie", "LE", y4_Skin$Locations)
y4_Skin$Locations <- gsub("Detroit_River", "DR", y4_Skin$Locations)
y4_Skin$Fishname <- gsub("Alewife", "Alewife", y4_Skin$Fishname)
y4_Skin$Fishname <- gsub("Blacknose_shiner", "Blacknose Shiner", y4_Skin$Fishname)
y4_Skin$Fishname <- gsub("Brook_silverside_fish", "Brook Silverside", y4_Skin$Fishname)
y4_Skin$Fishname <- gsub("Brown_Trout", "Brown Trout", y4_Skin$Fishname)
y4_Skin$Fishname <- gsub("Emerald", "Emerald", y4_Skin$Fishname)
y4_Skin$Fishname <- gsub("FD", "Freshwater Drum", y4_Skin$Fishname)
y4_Skin$Fishname <- gsub("Freshwater_drum", "Freshwater Drum", y4_Skin$Fishname)
y4_Skin$Fishname <- gsub("Freshwater_Drum", "Freshwater Drum", y4_Skin$Fishname)
y4_Skin$Fishname <- gsub("Gizzard_Shad", "American Gizzard Shad", y4_Skin$Fishname)
y4_Skin$Fishname <- gsub("Gizzard_shad", "American Gizzard Shad", y4_Skin$Fishname)
y4_Skin$Fishname <- gsub("Rock_Bass", "Rock Bass", y4_Skin$Fishname)
y4_Skin$Fishname <- gsub("Lake_Trout", "Lake Trout", y4_Skin$Fishname)
y4_Skin$Fishname <- gsub("Round_Goby", "Round Goby", y4_Skin$Fishname)
y4_Skin$Fishname <- gsub("Spotfin_shiner", "Spotfin Shiner", y4_Skin$Fishname)
y4_Skin$Fishname <- gsub("White_Bass", "White Bass", y4_Skin$Fishname)
y4_Skin$Fishname <- gsub("White_Perch", "White Perch", y4_Skin$Fishname)
y4_Skin$Fishname <- gsub("White_Sucker", "White Sucker", y4_Skin$Fishname)
y4_Skin$Fishname <- gsub("Yellow_perch", "Yellow Perch", y4_Skin$Fishname)
y4_Skin$Fishname <- gsub("Yellow_Perch", "Yellow Perch", y4_Skin$Fishname)

library(ggplot2)


pskin <- ggplot(data = y4_Skin, aes(x = Sample, y = Abundance, fill = Family)) +
  geom_bar(stat = "identity", position = "stack") +
  labs(x = "", y = "Relative Abundance %") +
  facet_wrap(~ Fishname + Locations, scales = "free") +
  theme(panel.background = element_blank(),
        axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        legend.text = element_text(size = 12, face = "bold.italic"),
        legend.position = "bottom",
        strip.text.x = element_text(size = 12, color = "Black", face = "bold"),
        strip.text.y = element_text(size = 12, color = "Black", face = "bold")) +
  guides(fill = guide_legend(nrow = 8, title = NULL))

pskin

```


<style>
.dl-inline {width: auto; margin:0; padding: 0}
.dl-inline>dt, .dl-inline>dd {float: none; width: auto; display: inline-block}
.dl-inline>dt::after {content: ":\0020"; padding-right: .5ex}
.dl-inline>dt:not(:first-of-type) {padding-left: .5ex}
</style><dl class=dl-inline><dt>S185</dt><dd>1010</dd><dt>S188</dt><dd>1114</dd><dt>S180</dt><dd>1235</dd><dt>S226</dt><dd>1400</dd><dt>S225</dt><dd>1421</dd><dt>S183</dt><dd>1529</dd><dt>S168</dt><dd>1645</dd><dt>S164</dt><dd>1690</dd><dt>S267</dt><dd>1770</dd><dt>S290</dt><dd>1849</dd><dt>S233</dt><dd>1934</dd><dt>S10</dt><dd>1964</dd><dt>S285</dt><dd>1967</dd><dt>S176</dt><dd>1969</dd><dt>S151</dt><dd>2167</dd><dt>S252</dt><dd>2168</dd><dt>S94</dt><dd>2218</dd><dt>S296</dt><dd>2420</dd><dt>S54</dt><dd>2508</dd><dt>S268</dt><dd>2620</dd><dt>S31</dt><dd>2724</dd><dt>S2</dt><dd>2751</dd><dt>S227</dt><dd>2761</dd><dt>S303</dt><dd>2774</dd><dt>S217</dt><dd>2802</dd><dt>S177</dt><dd>2921</dd><dt>S150</dt><dd>3068</dd><dt>S195</dt><dd>3153</dd><dt>S186</dt><dd>3191</dd><dt>S295</dt><dd>3253</dd><dt>S372</dt><dd>3456</dd><dt>S286</dt><dd>3588</dd><dt>S383</dt><dd>3670</dd><dt>S260</dt><dd>3689</dd><dt>S271</dt><dd>3845</dd><dt>S230</dt><dd>3886</dd><dt>S35</dt><dd>3908</dd><dt>S289</dt><dd>4059</dd><dt>S178</dt><dd>4258</dd><dt>S50</dt><dd>4266</dd><dt>S302</dt><dd>4279</dd><dt>S369</dt><dd>4280</dd><dt>S237</dt><dd>4291</dd><dt>S6</dt><dd>4416</dd><dt>S170</dt><dd>4478</dd><dt>S65</dt><dd>4512</dd><dt>S353</dt><dd>4558</dd><dt>S304</dt><dd>4596</dd><dt>S249</dt><dd>4686</dd><dt>S208</dt><dd>4781</dd><dt>S358</dt><dd>4876</dd><dt>S3</dt><dd>4881</dd><dt>S276</dt><dd>4886</dd><dt>S144</dt><dd>4954</dd><dt>S174</dt><dd>4958</dd><dt>S236</dt><dd>4973</dd><dt>S357</dt><dd>5074</dd><dt>S67</dt><dd>5166</dd><dt>S378</dt><dd>5272</dd><dt>S68</dt><dd>5308</dd><dt>S375</dt><dd>5326</dd><dt>S194</dt><dd>5481</dd><dt>S284</dt><dd>5494</dd><dt>S382</dt><dd>5536</dd><dt>S169</dt><dd>5636</dd><dt>S292</dt><dd>5687</dd><dt>S254</dt><dd>5808</dd><dt>S218</dt><dd>5857</dd><dt>S334</dt><dd>5880</dd><dt>S241</dt><dd>6075</dd><dt>S279</dt><dd>6146</dd><dt>S157</dt><dd>6162</dd><dt>S179</dt><dd>6228</dd><dt>S197</dt><dd>6340</dd><dt>S324</dt><dd>6409</dd><dt>S379</dt><dd>6631</dd><dt>S294</dt><dd>6632</dd><dt>S255</dt><dd>6711</dd><dt>S259</dt><dd>6783</dd><dt>S142</dt><dd>6843</dd><dt>S166</dt><dd>6856</dd><dt>S373</dt><dd>6886</dd><dt>S149</dt><dd>6959</dd><dt>S199</dt><dd>7032</dd><dt>S278</dt><dd>7147</dd><dt>S148</dt><dd>7159</dd><dt>S165</dt><dd>7250</dd><dt>S275</dt><dd>7492</dd><dt>S370</dt><dd>7513</dd><dt>S306</dt><dd>7547</dd><dt>S257</dt><dd>7661</dd><dt>S272</dt><dd>7731</dd><dt>S280</dt><dd>7741</dd><dt>S159</dt><dd>7777</dd><dt>S319</dt><dd>7879</dd><dt>S305</dt><dd>7953</dd><dt>S221</dt><dd>7964</dd><dt>S264</dt><dd>7972</dd><dt>S240</dt><dd>8254</dd><dt>S239</dt><dd>8340</dd><dt>S219</dt><dd>8436</dd><dt>S73</dt><dd>8670</dd><dt>S187</dt><dd>8762</dd><dt>S8</dt><dd>9039</dd><dt>S193</dt><dd>9078</dd><dt>S327</dt><dd>9121</dd><dt>S381</dt><dd>9151</dd><dt>S58</dt><dd>9185</dd><dt>S160</dt><dd>9314</dd><dt>S341</dt><dd>9415</dd><dt>S270</dt><dd>9417</dd><dt>S162</dt><dd>9499</dd><dt>S175</dt><dd>9621</dd><dt>S333</dt><dd>9626</dd><dt>S212</dt><dd>9725</dd><dt>S17</dt><dd>9812</dd><dt>S182</dt><dd>9840</dd><dt>S335</dt><dd>10198</dd><dt>S340</dt><dd>10232</dd><dt>S191</dt><dd>10338</dd><dt>S380</dt><dd>10343</dd><dt>S328</dt><dd>10358</dd><dt>S242</dt><dd>10373</dd><dt>S153</dt><dd>10392</dd><dt>S251</dt><dd>10404</dd><dt>S287</dt><dd>10509</dd><dt>S214</dt><dd>10606</dd><dt>S207</dt><dd>10690</dd><dt>S320</dt><dd>10737</dd><dt>S155</dt><dd>10812</dd><dt>S152</dt><dd>10967</dd><dt>S36</dt><dd>11211</dd><dt>S143</dt><dd>11401</dd><dt>S338</dt><dd>11549</dd><dt>S223</dt><dd>11555</dd><dt>S12</dt><dd>11620</dd><dt>S48</dt><dd>11679</dd><dt>S95</dt><dd>11811</dd><dt>S5</dt><dd>11829</dd><dt>S368</dt><dd>11949</dd><dt>S171</dt><dd>12119</dd><dt>S189</dt><dd>12176</dd><dt>S224</dt><dd>12178</dd><dt>S192</dt><dd>12196</dd><dt>S376</dt><dd>12272</dd><dt>S161</dt><dd>12283</dd><dt>S283</dt><dd>12338</dd><dt>S265</dt><dd>12455</dd><dt>S315</dt><dd>12502</dd><dt>S311</dt><dd>12566</dd><dt>S367</dt><dd>12623</dd><dt>S316</dt><dd>12631</dd><dt>S253</dt><dd>12645</dd><dt>S247</dt><dd>12717</dd><dt>S85</dt><dd>12755</dd><dt>S64</dt><dd>12795</dd><dt>S262</dt><dd>12810</dd><dt>S222</dt><dd>12810</dd><dt>S173</dt><dd>12924</dd><dt>S293</dt><dd>12924</dd><dt>S246</dt><dd>12962</dd><dt>S96</dt><dd>13212</dd><dt>S325</dt><dd>13283</dd><dt>S133</dt><dd>13304</dd><dt>S274</dt><dd>13308</dd><dt>S210</dt><dd>13398</dd><dt>S1</dt><dd>13422</dd><dt>S66</dt><dd>13453</dd><dt>S213</dt><dd>13713</dd><dt>S343</dt><dd>13792</dd><dt>S297</dt><dd>13947</dd><dt>S13</dt><dd>14067</dd><dt>S89</dt><dd>14225</dd><dt>S322</dt><dd>14310</dd><dt>S190</dt><dd>14337</dd><dt>S205</dt><dd>14356</dd><dt>S235</dt><dd>14447</dd><dt>S211</dt><dd>14507</dd><dt>S38</dt><dd>14522</dd><dt>S354</dt><dd>14572</dd><dt>S28</dt><dd>14970</dd><dt>S147</dt><dd>15113</dd><dt>S245</dt><dd>15143</dd><dt>S258</dt><dd>15143</dd><dt>S317</dt><dd>15158</dd><dt>S356</dt><dd>15163</dd><dt>S291</dt><dd>15172</dd><dt>S288</dt><dd>15350</dd><dt>S318</dt><dd>15408</dd><dt>S234</dt><dd>15545</dd><dt>S269</dt><dd>15873</dd><dt>S336</dt><dd>15905</dd><dt>S81</dt><dd>16110</dd><dt>S308</dt><dd>16255</dd><dt>S377</dt><dd>16264</dd><dt>S39</dt><dd>16341</dd><dt>S137</dt><dd>16498</dd><dt>S266</dt><dd>16673</dd><dt>S15</dt><dd>16896</dd><dt>S282</dt><dd>17143</dd><dt>S209</dt><dd>17869</dd><dt>S196</dt><dd>18220</dd><dt>S111</dt><dd>18267</dd><dt>S261</dt><dd>18335</dd><dt>S355</dt><dd>18593</dd><dt>S172</dt><dd>18804</dd><dt>S63</dt><dd>19373</dd><dt>S216</dt><dd>19428</dd><dt>S204</dt><dd>20510</dd><dt>S163</dt><dd>20557</dd><dt>S263</dt><dd>20862</dd><dt>S215</dt><dd>21001</dd><dt>S42</dt><dd>21415</dd><dt>S273</dt><dd>21636</dd><dt>S109</dt><dd>21684</dd><dt>S359</dt><dd>21817</dd><dt>S339</dt><dd>22025</dd><dt>S88</dt><dd>22764</dd><dt>S361</dt><dd>23050</dd><dt>S80</dt><dd>23457</dd><dt>S329</dt><dd>24065</dd><dt>S37</dt><dd>24084</dd><dt>S97</dt><dd>24131</dd><dt>S281</dt><dd>24313</dd><dt>S184</dt><dd>24511</dd><dt>S25</dt><dd>24693</dd><dt>S374</dt><dd>24829</dd><dt>S366</dt><dd>24843</dd><dt>S332</dt><dd>25142</dd><dt>S203</dt><dd>25294</dd><dt>S243</dt><dd>25750</dd><dt>S72</dt><dd>26103</dd><dt>S360</dt><dd>26285</dd><dt>S346</dt><dd>27291</dd><dt>S256</dt><dd>27453</dd><dt>S77</dt><dd>27530</dd><dt>S321</dt><dd>27703</dd><dt>S75</dt><dd>27811</dd><dt>S299</dt><dd>27931</dd><dt>S62</dt><dd>28792</dd><dt>S363</dt><dd>29024</dd><dt>S352</dt><dd>29192</dd><dt>S206</dt><dd>29241</dd><dt>S200</dt><dd>29385</dd><dt>S40</dt><dd>29497</dd><dt>S323</dt><dd>29755</dd><dt>S229</dt><dd>29887</dd><dt>S309</dt><dd>30073</dd><dt>S91</dt><dd>30122</dd><dt>S201</dt><dd>30288</dd><dt>S139</dt><dd>30339</dd><dt>S83</dt><dd>30693</dd><dt>S90</dt><dd>30737</dd><dt>S228</dt><dd>31122</dd><dt>S362</dt><dd>31275</dd><dt>S337</dt><dd>31362</dd><dt>S301</dt><dd>31479</dd><dt>S365</dt><dd>31519</dd><dt>S298</dt><dd>31792</dd><dt>S87</dt><dd>31837</dd><dt>S312</dt><dd>31888</dd><dt>S307</dt><dd>32583</dd><dt>S4</dt><dd>33403</dd><dt>S220</dt><dd>33580</dd><dt>S103</dt><dd>34548</dd><dt>S69</dt><dd>34700</dd><dt>S351</dt><dd>34980</dd><dt>S345</dt><dd>36109</dd><dt>S310</dt><dd>36465</dd><dt>S330</dt><dd>36511</dd><dt>S349</dt><dd>36665</dd><dt>S84</dt><dd>37007</dd><dt>S93</dt><dd>37040</dd><dt>S121</dt><dd>38628</dd><dt>S348</dt><dd>39220</dd><dt>S41</dt><dd>39534</dd><dt>S132</dt><dd>41048</dd><dt>S104</dt><dd>41804</dd><dt>S347</dt><dd>42604</dd><dt>S135</dt><dd>42617</dd><dt>S238</dt><dd>43213</dd><dt>S110</dt><dd>43408</dd><dt>S102</dt><dd>44037</dd><dt>S98</dt><dd>44105</dd><dt>S107</dt><dd>44178</dd><dt>S331</dt><dd>44321</dd><dt>S198</dt><dd>45140</dd><dt>S140</dt><dd>46363</dd><dt>S364</dt><dd>48055</dd><dt>S101</dt><dd>50960</dd><dt>S76</dt><dd>51522</dd><dt>S371</dt><dd>52535</dd><dt>S313</dt><dd>53231</dd><dt>S314</dt><dd>53827</dd><dt>S202</dt><dd>53999</dd><dt>S106</dt><dd>54204</dd><dt>S122</dt><dd>56348</dd><dt>S167</dt><dd>60364</dd><dt>S79</dt><dd>60938</dd><dt>S350</dt><dd>61933</dd><dt>S70</dt><dd>63300</dd><dt>S86</dt><dd>65870</dd><dt>S125</dt><dd>66919</dd><dt>S130</dt><dd>68525</dd><dt>S105</dt><dd>69449</dd><dt>S99</dt><dd>69841</dd><dt>S82</dt><dd>72590</dd><dt>S108</dt><dd>72761</dd><dt>S78</dt><dd>73400</dd><dt>S129</dt><dd>75734</dd><dt>S127</dt><dd>78275</dd><dt>S344</dt><dd>78291</dd><dt>S123</dt><dd>78518</dd><dt>S138</dt><dd>79510</dd><dt>S124</dt><dd>79971</dd><dt>S300</dt><dd>82584</dd><dt>S112</dt><dd>83161</dd><dt>S134</dt><dd>83729</dd><dt>S100</dt><dd>84468</dd><dt>S126</dt><dd>85167</dd><dt>S131</dt><dd>86375</dd><dt>S119</dt><dd>133524</dd><dt>S74</dt><dd>136728</dd><dt>S71</dt><dd>156028</dd></dl>




    phyloseq-class experiment-level object
    otu_table()   OTU Table:         [ 5281 taxa and 324 samples ]
    sample_data() Sample Data:       [ 324 samples by 9 sample variables ]
    tax_table()   Taxonomy Table:    [ 5281 taxa by 5 taxonomic ranks ]
    phy_tree()    Phylogenetic Tree: [ 5281 tips and 4898 internal nodes ]



    
                      Abditibacteriaceae          Absconditabacteriales_(SR1) 
                                       6                                   11 
                        Acetobacteraceae                   Acidaminococcaceae 
                                      56                                    2 
                          Acidobacteriae                     Actinomycetaceae 
                                      12                                    1 
                            ADurb.Bin180                       Aeromonadaceae 
                                       1                                   54 
                                 AKYH767                       Alcaligenaceae 
                                       4                                   28 
                        Alteromonadaceae                      Aminicenantales 
                                      47                                   28 
                         Amoebophilaceae                      Anaerolineaceae 
                                       1                                   30 
                   Anaeromyxobacteraceae                     Anaerovoracaceae 
                                       4                                    7 
                         Anaplasmataceae                      Arcobacteraceae 
                                       2                                   10 
                          Arenicellaceae                     Armatimonadaceae 
                                       4                                    2 
                                AT-s3-28                               B1-7BS 
                                       2                                   11 
                              Babeliales                          Bacillaceae 
                                      13                                   26 
                      Bacteriovoracaceae                       Bacteroidaceae 
                                      30                                    1 
                 Bacteroidetes_vadinHA17            Bacteroidetes_VC2.1_Bac22 
                                      12                                    1 
                         Barnesiellaceae                   Bdellovibrionaceae 
                                       8                                   22 
                           Beggiatoaceae                     Beijerinckiaceae 
                                       7                                   73 
                       Blastocatellaceae                              Blfdi19 
                                      30                                    1 
                          Bradymonadales                     Brevibacillaceae 
                                       1                                    3 
                       Brevibacteriaceae                      Brevinemataceae 
                                       5                                    2 
                         Bryobacteraceae                     Burkholderiaceae 
                                       6                                   45 
                        Caedibacteraceae                       Caldilineaceae 
                                       3                                   45 
                        Caloramatoraceae             Candidatus_Adlerbacteria 
                                       1                                    6 
               Candidatus_Kaiserbacteria           Candidatus_Kerfeldbacteria 
                                       1                                    1 
                Candidatus_Moranbacteria         Candidatus_Peregrinibacteria 
                                       2                                    8 
                      Carboxydocellaceae                    Carnobacteriaceae 
                                       2                                    4 
                        Caulobacteraceae                               CCM11a 
                                      60                                    2 
                                  CCM19a                     Cellvibrionaceae 
                                       4                                    8 
                      Chitinibacteraceae                    Chitinimonadaceae 
                                      29                                    7 
                        Chitinophagaceae                        Chlamydiaceae 
                                      86                                    1 
             Chlamydiales_Incertae_Sedis                          Chloroplast 
                                      12                                   74 
                     Christensenellaceae                   Chromobacteriaceae 
                                       9                                   22 
                    Chroococcidiopsaceae                  Chthoniobacteraceae 
                                       1                                   46 
                               Clade_III                       Clostridiaceae 
                                       2                                  113 
                          Comamonadaceae                   Competibacteraceae 
                                     193                                    1 
                      Corynebacteriaceae                         Coxiellaceae 
                                       6                                    2 
                                    CPR2                    Crocinitomicaceae 
                                       2                                   10 
                          Cryomorphaceae                                 cvE6 
                                       1                                    2 
                            Cyanobiaceae                    Cyclobacteriaceae 
                                      17                                   18 
                           Cytophagaceae                                D05-2 
                                       7                                    4 
                      Deferribacteraceae                    Defluviicoccaceae 
                                       1                                    1 
                          Deinococcaceae                     Desulfarculaceae 
                                      36                                    3 
                     Desulfatiglandaceae                     Desulfobaccaceae 
                                       7                                    9 
                        Desulfobulbaceae                     Desulfocapsaceae 
                                       6                                   17 
                       Desulfomonilaceae                   Desulfosarcinaceae 
                                      10                                   14 
                     Desulfovibrionaceae                               DEV007 
                                       8                                    5 
                             Devosiaceae                          Dietziaceae 
                                      25                                    7 
                     Diplorickettsiaceae                               DS-100 
                                      13                                    1 
                       Dysgonomonadaceae                          EF100-94H03 
                                       2                                    2 
                         Emcibacteraceae                   Enterobacteriaceae 
                                       3                                   53 
                         Enterococcaceae                           env.OPS_17 
                                       1                                   12 
                             Erwiniaceae                  Erysipelotrichaceae 
                                       8                                    6 
                       Exiguobacteraceae                              FCPU426 
                                      16                                    1 
                       Ferrovibrionaceae                     Ferrovibrionales 
                                       2                                    3 
                       Fimbriimonadaceae                    Flavobacteriaceae 
                                       1                                   53 
                       Fodinicurvataceae                          Fokiniaceae 
                                       3                                   11 
                              Frankiales                     Fusobacteriaceae 
                                       2                                   40 
                               Ga0077536                      Gallionellaceae 
                                       1                                    2 
                             Gemellaceae                          Gemmataceae 
                                       1                                   37 
                       Gemmatimonadaceae                       Geobacteraceae 
                                      13                                   11 
                     Geodermatophilaceae                       Gloeocapsaceae 
                                       3                                    1 
                              Hafniaceae                        Haliangiaceae 
                                       1                                    1 
                              Halieaceae                       Halomonadaceae 
                                      24                                   19 
                      Herpetosiphonaceae                        Holophagaceae 
                                       1                                    3 
                           Holosporaceae               Hungateiclostridiaceae 
                                      13                                    1 
                      Hydrogenedensaceae                   Hydrogenophilaceae 
                                       2                                    7 
                       Hymenobacteraceae                    Hyphomicrobiaceae 
                                       6                                   15 
                         Hyphomonadaceae                            Iamiaceae 
                                      16                                    7 
                      Ignavibacteriaceae                   Ilumatobacteraceae 
                                       1                                   64 
                               IMCC26256                   Intrasporangiaceae 
                                      12                                    3 
                          Isosphaeraceae                         JG30-KF-CM45 
                                      32                                    3 
                              JG36-GS-52                          Kaistiaceae 
                                       1                                    2 
                         Kapabacteriales                        KCLunmb-38-53 
                                      17                                    1 
                                  KD4-96                          KI89A_clade 
                                      22                                    1 
                         Lachnospiraceae                     Lactobacillaceae 
                                      44                                    1 
                        Latescibacterota                             LD-RB-34 
                                       3                                    2 
                                 LD1-PB3                       Legionellaceae 
                                       3                                   55 
                                Lenti-02                    Lentimicrobiaceae 
                                       1                                    6 
                        Leptolyngbyaceae                       Leptospiraceae 
                                       3                                    1 
                        Leptotrichiaceae                     Leuconostocaceae 
                                       1                                    1 
                         Limnotrichaceae                         Listeriaceae 
                                       2                                    1 
                       Longimicrobiaceae                        MAT-CR-H6-H10 
                                       1                                    1 
                               MB-A2-108                               MBNT15 
                                      12                                    5 
                Methanomassiliicoccaceae                    Methanoregulaceae 
                                       1                                    8 
                        Methanosaetaceae                 Methylacidiphilaceae 
                                       1                                    7 
                        Methylococcaceae                   Methyloligellaceae 
                                      12                                    2 
                     Methylomirabilaceae                    Methylomonadaceae 
                                       2                                   14 
                        Methylophilaceae                    Microbacteriaceae 
                                      14                                   45 
                          Micrococcaceae                       Microcystaceae 
                                      37                                   11 
                          Micropepsaceae                      Microscillaceae 
                                       1                                    7 
                         Microtrichaceae                               MidBa8 
                                       4                                    1 
                            Mitochondria                              mle1-27 
                                       6                                    1 
                         Moduliflexaceae                        Moraxellaceae 
                                       1                                   82 
                          Morganellaceae                              MSB-5B2 
                                       1                                    5 
                 MWH-UniP1_aquatic_group                     Mycobacteriaceae 
                                       4                                   11 
                        Mycoplasmataceae                        Myxococcaceae 
                                      52                                    1 
                          Nannocystaceae                                NB1-j 
                                       2                                   12 
                           Neisseriaceae                    Nitrosomonadaceae 
                                       6                                    8 
                       Nitrosopumilaceae                       Nitrospiraceae 
                                       2                                    4 
                            Nocardiaceae                      Nocardioidaceae 
                                       5                                    5 
                         Nodosilineaceae                          Nostocaceae 
                                       2                                    2 
                    NS11-12_marine_group                     NS9_marine_group 
                                       7                                    3 
                                    OC31                        Oligoflexales 
                                       1                                    2 
                                   OM190                       Omnitrophaceae 
                                      11                                    8 
                                   OPB41                     Oxalobacteraceae 
                                       4                                   76 
                               P9X2b3D02                     Paenibacillaceae 
                                      12                                   11 
                       Paludibacteraceae                 Paracaedibacteraceae 
                                       4                                   12 
                       Parachlamydiaceae                      Pasteurellaceae 
                                      10                                    3 
                                    PB19                      Pedosphaeraceae 
                                       4                                   41 
                                   PeM15                Peptostreptococcaceae 
                                      11                                   45 
     Peptostreptococcales-Tissierellales                        Phormidiaceae 
                                       2                                    6 
                               PHOS-HE36                     Phycisphaeraceae 
                                       1                                   18 
                           Pirellulaceae                         Pla1_lineage 
                                     285                                    5 
                          Planococcaceae                               PLTA13 
                                      15                                    1 
                           Polyangiaceae                   Prolixibacteraceae 
                                       3                                    4 
                   Promicromonosporaceae                 Propionibacteriaceae 
                                       1                                    5 
                       Pseudanabaenaceae                  Pseudohongiellaceae 
                                       9                                    1 
                        Pseudomonadaceae                   Puniceispirillales 
                                      71                                    1 
                             RBG-13-54-9                       Reyranellaceae 
                                      18                                   16 
                            Rhizobiaceae           Rhizobiales_Incertae_Sedis 
                                      84                                   44 
                      Rhodanobacteraceae                     Rhodobacteraceae 
                                      12                                   99 
                          Rhodocyclaceae                    Rhodospirillaceae 
                                      24                                    2 
                          Rickettsiaceae                       Roseiflexaceae 
                                      16                                    5 
                       Rubinisphaeraceae                       Rubritaleaceae 
                                      37                                   14 
                         Ruminococcaceae                   Saccharimonadaceae 
                                       6                                    6 
                       Saccharimonadales                 Saccharospirillaceae 
                                      54                                    1 
                         Sandaracinaceae                    Sanguibacteraceae 
                                       5                                    2 
                          Saprospiraceae         SAR324_clade(Marine_group_B) 
                                      13                                    7 
                                 SBR1031                              SC-I-84 
                                       3                                   51 
                         Schlesneriaceae                    Sericytochromatia 
                                      15                                    4 
                                   SG8-4                       Shewanellaceae 
                                       1                                   33 
                       Silvanigrellaceae                         Simkaniaceae 
                                      10                                    2 
                                  SJA-15                               SJA-28 
                                      14                                   18 
                       SL56_marine_group                               SM2D12 
                                       4                                    2 
                           Smithellaceae                       Solimonadaceae 
                                       1                                    3 
                     Sphingobacteriaceae                    Sphingomonadaceae 
                                      91                                  108 
                           Spirosomaceae                   Spongiibacteraceae 
                                      36                                    1 
                         Sporichthyaceae                        Sporomusaceae 
                                      32                                    9 
                                ST-12K33                    Staphylococcaceae 
                                       6                                   19 
                     Steroidobacteraceae                     Streptococcaceae 
                                      21                                   22 
                             Subgroup_11                          Subgroup_17 
                                       3                                   30 
                             Subgroup_22                           Subgroup_7 
                                       4                                   15 
                     Succinivibrionaceae                    Sulfurimonadaceae 
                                       1                                    1 
                           Sumerlaeaceae                       Sutterellaceae 
                                       8                                    9 
                                 Sva0485                       Synergistaceae 
                                      10                                   10 
                    Syntrophobacteraceae                  Syntrophomonadaceae 
                                      10                                    1 
                     Syntrophorhabdaceae                                SZB30 
                                       8                                    5 
                                    TA06                       Tannerellaceae 
                                       1                                   12 
                       Tepidisphaeraceae                    Terrimicrobiaceae 
                                       1                                   15 
                          Thermicanaceae               Thermoactinomycetaceae 
                                       1                                    1 
                  Thermoanaerobaculaceae                              TRA3-20 
                                      10                                    2 
                               vadinHA49                      Veillonellaceae 
                                       2                                    5 
                          Vermiphilaceae                  Verrucomicrobiaceae 
                                       4                                   71 
                            Vibrionaceae                  Vicinamibacteraceae 
                                       9                                   57 
                                WCHB1-02                             WCHB1-41 
                                       2                                   33 
                                WCHB1-81                    WD2101_soil_group 
                                       9                                   13 
                           Weeksellaceae                 Williamwhitmaniaceae 
                                      78                                    2 
                   Wohlfahrtiimonadaceae                                WPS-2 
                                       3                                    4 
                                     WS1                    Xanthobacteraceae 
                                       6                                   26 
                        Xanthomonadaceae               Xiphinematobacteraceae 
                                      61                                    1 



    
![png](output_6_3.png)
    



### Creat NMD plot based on sample type
Non-metric multidimensional scaling (NMDS) plot using the Bray-Curtis distance matrix was generated using vegan (v.2.5 or lower) and ggplot2 (v.3.3.5) packages in R (v.4.1.0) to visualize clustering among the sample types (skin, gut, and water). 
More info can be found in here: https://jkzorz.github.io/2019/06/06/NMDS.html 





```R

library(ggplot2)
library(vegan)


All= read.delim("All.txt", sep = "\t" , row.names = 1)

com = All[,8:ncol(All)]


m_com = as.matrix(com)


set.seed(123)
nmds = metaMDS(m_com, distance = "bray")
nmds


plot(nmds)

```

    Square root transformation
    Wisconsin double standardization
    Run 0 stress 0.2293216 
    Run 1 stress 0.2433358 
    Run 2 stress 0.2355772 
    Run 3 stress 0.2309951 
    Run 4 stress 0.2295255 
    ... Procrustes: rmse 0.01749563  max resid 0.1520331 
    Run 5 stress 0.2383045 
    Run 6 stress 0.2436771 
    Run 7 stress 0.2331582 
    Run 8 stress 0.2318967 
    Run 9 stress 0.243908 
    Run 10 stress 0.2276427 
    ... New best solution
    ... Procrustes: rmse 0.01690616  max resid 0.1442272 
    Run 11 stress 0.2282514 
    Run 12 stress 0.2335565 
    Run 13 stress 0.229849 
    Run 14 stress 0.2301801 
    Run 15 stress 0.2356278 
    Run 16 stress 0.2366811 
    Run 17 stress 0.2310442 
    Run 18 stress 0.2318733 
    Run 19 stress 0.2333996 
    Run 20 stress 0.233519 
    *** Best solution was not repeated -- monoMDS stopping criteria:
         7: no. of iterations >= maxit
         8: stress ratio > sratmax
         5: scale factor of the gradient < sfgrmin
    


    
    Call:
    metaMDS(comm = m_com, distance = "bray") 
    
    global Multidimensional Scaling using monoMDS
    
    Data:     wisconsin(sqrt(m_com)) 
    Distance: bray 
    
    Dimensions: 2 
    Stress:     0.2276427 
    Stress type 1, weak ties
    Best solution was not repeated after 20 tries
    The best solution was from try 10 (random start)
    Scaling: centring, PC rotation, halfchange scaling 
    Species: expanded scores based on 'wisconsin(sqrt(m_com))' 
    



    
![png](output_8_2.png)
    


###  Differential abundance analysis at the family level was used to acquire more specific insight into differences in microbiome composition between the gut and skin microbiomes the negative binomial Wald test in DESeq2 


```R
library(DESeq2)
ct<-read.table("At_family_level_Skin_Gut.txt",header=T)

cts <- ct+1


coldata<-read.table("Skin_Gut_meta_data.txt",header=T)
str(coldata$sample_type)

coldata$sample_type<- as.factor(coldata$sample_type)
str(coldata$sample_type)
dds <- DESeqDataSetFromMatrix(countData = cts,
                              colData = coldata,
                              design <- ~ sample_type)




View(counts(dds))
dds <- estimateSizeFactors(dds)



sizeFactors(dds)


normalized_counts <- counts(dds, normalized=TRUE)


###write.table(normalized_counts, file="normalized_counts.txt", sep="\t", quote=F, col.names=NA)




dds <- DESeq(dds)


sample_type_Skin_vs_Gut <- results(dds, contrast=c("sample_type","Skin","Gut"))

resOrderedssample_type_Skin_vs_Gut <- sample_type_Skin_vs_Gut[order(sample_type_Skin_vs_Gut$pvalue),]


###write.csv(as.data.frame(resOrderedssample_type_Skin_vs_Gut), 
##file="new_resOrderedssample_type_Skin_vs_Gut.csv")


```

     chr [1:617] "Gut" "Gut" "Gut" "Gut" "Gut" "Gut" "Gut" "Gut" "Gut" "Gut" ...
     Factor w/ 2 levels "Gut","Skin": 1 1 1 1 1 1 1 1 1 1 ...
    

    converting counts to integer mode
    
    


<table class="dataframe">
<caption>A matrix: 86 × 617 of type int</caption>
<thead>
	<tr><th></th><th scope=col>G1</th><th scope=col>G2</th><th scope=col>G3</th><th scope=col>G4</th><th scope=col>G5</th><th scope=col>G6</th><th scope=col>G7</th><th scope=col>G8</th><th scope=col>G9</th><th scope=col>G10</th><th scope=col>⋯</th><th scope=col>S374</th><th scope=col>S375</th><th scope=col>S376</th><th scope=col>S377</th><th scope=col>S378</th><th scope=col>S379</th><th scope=col>S380</th><th scope=col>S381</th><th scope=col>S382</th><th scope=col>S383</th></tr>
</thead>
<tbody>
	<tr><th scope=row>Subgroup_17</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td>  1</td><td>  1</td><td>  32</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Vicinamibacteraceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td>  1</td><td>  1</td><td>   1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>IMCC26256</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td>22</td><td>⋯</td><td>  1</td><td>  1</td><td>   1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Ilumatobacteraceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td>11</td><td>⋯</td><td>  1</td><td>  1</td><td>   1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Sporichthyaceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td> 91</td><td>  1</td><td>   1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Microbacteriaceae</th><td>1</td><td>11</td><td>494</td><td>831</td><td>32</td><td>15</td><td>161</td><td>8</td><td>5</td><td>37</td><td>⋯</td><td>  1</td><td> 52</td><td>  34</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Micrococcaceae</th><td>1</td><td> 1</td><td>  1</td><td>  4</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td>218</td><td> 69</td><td> 485</td><td> 87</td><td> 76</td><td> 45</td><td>169</td><td> 84</td><td>156</td><td> 1</td></tr>
	<tr><th scope=row>PeM15</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td>  1</td><td>  1</td><td>   1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Propionibacteriaceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td>  1</td><td>  1</td><td>   1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Barnesiellaceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td> 71</td><td>  1</td><td>   1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Chitinophagaceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td> 76</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td> 11</td><td>  1</td><td>   1</td><td> 93</td><td>  1</td><td> 24</td><td>  1</td><td>  1</td><td> 48</td><td> 1</td></tr>
	<tr><th scope=row>Cyclobacteriaceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td>  1</td><td>  1</td><td>   1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Flavobacteriaceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td>  1</td><td>  1</td><td>   1</td><td>  1</td><td> 11</td><td> 29</td><td>  1</td><td> 34</td><td>  1</td><td>19</td></tr>
	<tr><th scope=row>Weeksellaceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td> 19</td><td> 27</td><td> 626</td><td>391</td><td>130</td><td>131</td><td>173</td><td>595</td><td> 64</td><td> 1</td></tr>
	<tr><th scope=row>Sphingobacteriaceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td> 76</td><td>161</td><td>1028</td><td>  1</td><td>  1</td><td> 10</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Bacteriovoracaceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td>  1</td><td>  1</td><td>   1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Bdellovibrionaceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td>  1</td><td>  1</td><td>   1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>N1_20</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td>  1</td><td>  1</td><td>  42</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Caldilineaceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td> 13</td><td>  1</td><td>   9</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>KD4-96</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td>  1</td><td>  1</td><td>  22</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Chloroplast</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td>25</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td>  1</td><td>  1</td><td>   1</td><td>186</td><td> 27</td><td> 74</td><td>  1</td><td> 77</td><td> 39</td><td>37</td></tr>
	<tr><th scope=row>Microcystaceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td>  1</td><td>  1</td><td>   1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Phormidiaceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td>  1</td><td>  4</td><td>  19</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Cyanobiaceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td> 28</td><td>  1</td><td>   1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Deinococcaceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td> 65</td><td> 42</td><td> 127</td><td>  8</td><td>  1</td><td>  4</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Babeliales</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td>  1</td><td>  1</td><td>  25</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Desulfocapsaceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 7</td><td>⋯</td><td>  1</td><td> 17</td><td>   1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Bacillaceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td> 23</td><td>  1</td><td>   1</td><td>299</td><td> 67</td><td>104</td><td> 59</td><td>121</td><td> 83</td><td> 1</td></tr>
	<tr><th scope=row>Planococcaceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td>198</td><td>115</td><td> 104</td><td> 26</td><td>  7</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>Exiguobacteraceae</th><td>1</td><td> 1</td><td>  1</td><td>  1</td><td> 1</td><td> 1</td><td>  1</td><td>1</td><td>1</td><td> 1</td><td>⋯</td><td> 60</td><td>115</td><td> 487</td><td>  1</td><td>  1</td><td>  1</td><td>  1</td><td>289</td><td>  1</td><td> 1</td></tr>
	<tr><th scope=row>⋮</th><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋱</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><th scope=row>Rickettsiaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td>   1</td><td>⋯</td><td>  64</td><td>  1</td><td>   3</td><td>  80</td><td>  24</td><td>  18</td><td>  26</td><td>   1</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>Sphingomonadaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td>   1</td><td>⋯</td><td>  65</td><td> 55</td><td>  57</td><td>  27</td><td>   1</td><td>   1</td><td>   1</td><td>  19</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>Aeromonadaceae</th><td>16841</td><td>12150</td><td>12252</td><td>1398</td><td>32635</td><td>18247</td><td> 593</td><td>6492</td><td>  174</td><td>5239</td><td>⋯</td><td> 155</td><td>  1</td><td>   1</td><td>9980</td><td>3348</td><td>4203</td><td>3587</td><td>5443</td><td>3442</td><td>698</td></tr>
	<tr><th scope=row>Alteromonadaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td>   1</td><td>⋯</td><td>   1</td><td>  1</td><td>  19</td><td> 478</td><td> 121</td><td> 152</td><td>  60</td><td> 211</td><td>  95</td><td>231</td></tr>
	<tr><th scope=row>Shewanellaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td> 155</td><td>    1</td><td>   1</td><td>⋯</td><td>   1</td><td>  1</td><td>   1</td><td>  24</td><td>  65</td><td> 158</td><td>   1</td><td>  37</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>Alcaligenaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    4</td><td>   1</td><td>   1</td><td>    1</td><td>   7</td><td>⋯</td><td>  64</td><td> 89</td><td>  78</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>B1-7BS</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td>   1</td><td>⋯</td><td>   1</td><td>  1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>Burkholderiaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td> 102</td><td>   1</td><td>    1</td><td>   1</td><td>⋯</td><td>3764</td><td>474</td><td> 222</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>Chitinibacteraceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td>   1</td><td>⋯</td><td>  26</td><td>  1</td><td>   1</td><td> 219</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>  34</td><td>  1</td></tr>
	<tr><th scope=row>Chromobacteriaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td>   1</td><td>⋯</td><td>   1</td><td>  1</td><td>   1</td><td>  48</td><td>   8</td><td>   7</td><td>   1</td><td>  11</td><td>   1</td><td>  9</td></tr>
	<tr><th scope=row>Comamonadaceae</th><td>    1</td><td>    1</td><td>  158</td><td>   1</td><td>    1</td><td>    1</td><td> 219</td><td>  16</td><td>    1</td><td> 108</td><td>⋯</td><td> 460</td><td>394</td><td>1661</td><td> 320</td><td>   1</td><td>  58</td><td> 119</td><td> 208</td><td>  74</td><td> 41</td></tr>
	<tr><th scope=row>Oxalobacteraceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td>   1</td><td>⋯</td><td> 122</td><td> 43</td><td>  50</td><td>  92</td><td>  17</td><td>   1</td><td>  14</td><td>   1</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>Rhodocyclaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>  20</td><td>   1</td><td>    1</td><td>   1</td><td>⋯</td><td>   1</td><td>  1</td><td>  12</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>SC-I-84</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td> 190</td><td>⋯</td><td>  61</td><td>  1</td><td>  65</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>Sutterellaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td>   1</td><td>⋯</td><td>   1</td><td>  1</td><td>  69</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>Halieaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td>   1</td><td>⋯</td><td>  29</td><td>  1</td><td>   1</td><td>  52</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>Enterobacteriaceae</th><td>  534</td><td> 2545</td><td> 1814</td><td> 524</td><td>  120</td><td>  704</td><td>9718</td><td> 524</td><td>36446</td><td>3847</td><td>⋯</td><td>1476</td><td>744</td><td> 568</td><td> 617</td><td> 138</td><td> 299</td><td> 139</td><td>   1</td><td> 347</td><td> 85</td></tr>
	<tr><th scope=row>Legionellaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td> 101</td><td>⋯</td><td> 189</td><td>118</td><td>  28</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>Methylomonadaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td>   1</td><td>⋯</td><td>   1</td><td>  1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>Halomonadaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td>   1</td><td>⋯</td><td>   1</td><td>  1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>Moraxellaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td> 173</td><td>   5</td><td>    1</td><td>   1</td><td>⋯</td><td> 150</td><td> 45</td><td> 312</td><td>1149</td><td> 809</td><td> 694</td><td>5262</td><td>1214</td><td> 538</td><td> 26</td></tr>
	<tr><th scope=row>Pseudomonadaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    8</td><td>    1</td><td>  82</td><td>   1</td><td>    1</td><td>   1</td><td>⋯</td><td> 283</td><td>150</td><td>1339</td><td> 487</td><td> 228</td><td> 280</td><td> 527</td><td> 239</td><td> 179</td><td> 18</td></tr>
	<tr><th scope=row>Steroidobacteraceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td>   9</td><td>⋯</td><td>  43</td><td>  1</td><td>  61</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>Xanthomonadaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>  62</td><td>   6</td><td>    1</td><td>  11</td><td>⋯</td><td>1022</td><td>241</td><td>1465</td><td>  56</td><td>   1</td><td>   1</td><td>  49</td><td> 102</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>Chthoniobacteraceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td>  55</td><td>⋯</td><td> 119</td><td>  1</td><td>  54</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>Terrimicrobiaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td>   1</td><td>⋯</td><td> 356</td><td> 37</td><td>  83</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>Methylacidiphilaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td>   1</td><td>⋯</td><td>  18</td><td>  1</td><td>   1</td><td>   1</td><td>   6</td><td>   1</td><td>   1</td><td>  18</td><td>  10</td><td>  1</td></tr>
	<tr><th scope=row>Pedosphaeraceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td>   1</td><td>⋯</td><td>   1</td><td>  1</td><td>   3</td><td>   1</td><td>   1</td><td>   4</td><td>   1</td><td>   1</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>Verrucomicrobiaceae</th><td>    1</td><td>    1</td><td>    1</td><td>   1</td><td>    1</td><td>    1</td><td>   1</td><td>   1</td><td>    1</td><td>   1</td><td>⋯</td><td>   1</td><td>  1</td><td>   1</td><td>  27</td><td>   7</td><td>   1</td><td>   1</td><td>   1</td><td>   1</td><td>  1</td></tr>
	<tr><th scope=row>Unknown</th><td>  899</td><td>    5</td><td>  248</td><td>   1</td><td> 3522</td><td> 1459</td><td> 404</td><td>   6</td><td>    1</td><td>  19</td><td>⋯</td><td>2735</td><td> 88</td><td>  86</td><td> 418</td><td> 103</td><td> 265</td><td> 147</td><td> 291</td><td> 160</td><td>239</td></tr>
</tbody>
</table>




<style>
.dl-inline {width: auto; margin:0; padding: 0}
.dl-inline>dt, .dl-inline>dd {float: none; width: auto; display: inline-block}
.dl-inline>dt::after {content: ":\0020"; padding-right: .5ex}
.dl-inline>dt:not(:first-of-type) {padding-left: .5ex}
</style><dl class=dl-inline><dt>G1</dt><dd>0.433785950811821</dd><dt>G2</dt><dd>0.440157701071704</dd><dt>G3</dt><dd>0.471882421985132</dd><dt>G4</dt><dd>0.440157701071704</dd><dt>G5</dt><dd>0.440157701071704</dd><dt>G6</dt><dd>0.471882421985132</dd><dt>G7</dt><dd>0.545889810313124</dd><dt>G8</dt><dd>0.460974547626375</dd><dt>G9</dt><dd>0.460974547626375</dd><dt>G10</dt><dd>0.604932997932187</dd><dt>G11</dt><dd>0.489140569280338</dd><dt>G12</dt><dd>0.51512015532718</dd><dt>G13</dt><dd>0.578158941611559</dd><dt>G14</dt><dd>0.536924116839172</dd><dt>G15</dt><dd>0.440157701071704</dd><dt>G16</dt><dd>0.715905602096421</dd><dt>G17</dt><dd>0.563141863581101</dd><dt>G18</dt><dd>0.653974641560693</dd><dt>G19</dt><dd>0.526091697462466</dd><dt>G20</dt><dd>0.536924116839172</dd><dt>G21</dt><dd>0.619505731338351</dd><dt>G22</dt><dd>0.52023746247388</dd><dt>G23</dt><dd>0.52023746247388</dd><dt>G24</dt><dd>0.547585289014435</dd><dt>G25</dt><dd>0.526091697462466</dd><dt>G26</dt><dd>0.440157701071704</dd><dt>G27</dt><dd>0.539162586919637</dd><dt>G28</dt><dd>0.680702272947343</dd><dt>G29</dt><dd>0.501117144673946</dd><dt>G30</dt><dd>0.526091697462466</dd><dt>G31</dt><dd>0.484769370326196</dd><dt>G32</dt><dd>0.563141863581101</dd><dt>G33</dt><dd>0.489140569280338</dd><dt>G34</dt><dd>0.628626247022891</dd><dt>G35</dt><dd>0.565269237730562</dd><dt>G36</dt><dd>0.66568090061631</dd><dt>G37</dt><dd>0.489140569280338</dd><dt>G38</dt><dd>0.526091697462466</dd><dt>G39</dt><dd>0.62660603619867</dd><dt>G40</dt><dd>0.588482427445928</dd><dt>G41</dt><dd>0.637496855980251</dd><dt>G42</dt><dd>0.451817369137871</dd><dt>G43</dt><dd>0.485488283310064</dd><dt>G44</dt><dd>0.440157701071704</dd><dt>G45</dt><dd>0.539162586919637</dd><dt>G46</dt><dd>0.440157701071704</dd><dt>G47</dt><dd>0.532710215583802</dd><dt>G48</dt><dd>0.484769370326196</dd><dt>G49</dt><dd>0.653974641560693</dd><dt>G50</dt><dd>0.602988929901081</dd><dt>G51</dt><dd>0.653974641560693</dd><dt>G52</dt><dd>0.565269237730562</dd><dt>G53</dt><dd>0.602988929901081</dd><dt>G54</dt><dd>0.637496855980251</dd><dt>G55</dt><dd>0.628626247022891</dd><dt>G56</dt><dd>0.563141863581101</dd><dt>G57</dt><dd>0.686753352983239</dd><dt>G58</dt><dd>0.52023746247388</dd><dt>G59</dt><dd>0.471882421985132</dd><dt>G60</dt><dd>0.602988929901081</dd><dt>G61</dt><dd>0.51512015532718</dd><dt>G62</dt><dd>0.66568090061631</dd><dt>G63</dt><dd>0.51512015532718</dd><dt>G64</dt><dd>0.55651223346432</dd><dt>G65</dt><dd>0.637496855980251</dd><dt>G66</dt><dd>0.66568090061631</dd><dt>G67</dt><dd>0.602988929901081</dd><dt>G68</dt><dd>0.680702272947343</dd><dt>G69</dt><dd>0.660382509325181</dd><dt>G70</dt><dd>0.683987275859573</dd><dt>G71</dt><dd>0.686753352983239</dd><dt>G72</dt><dd>0.646632469546676</dd><dt>G73</dt><dd>0.646632469546676</dd><dt>G74</dt><dd>0.501117144673946</dd><dt>G75</dt><dd>0.659433812767765</dd><dt>G76</dt><dd>0.533274819834484</dd><dt>G77</dt><dd>0.539162586919637</dd><dt>G78</dt><dd>0.628626247022891</dd><dt>G79</dt><dd>0.526091697462466</dd><dt>G81</dt><dd>0.440157701071704</dd><dt>G82</dt><dd>0.619505731338351</dd><dt>G83</dt><dd>0.637496855980251</dd><dt>G84</dt><dd>0.539162586919637</dd><dt>G86</dt><dd>0.637496855980251</dd><dt>G87</dt><dd>0.659433812767765</dd><dt>G88</dt><dd>0.743681530576145</dd><dt>G89</dt><dd>0.602988929901081</dd><dt>G90</dt><dd>0.653974641560693</dd><dt>G91</dt><dd>0.427341052978041</dd><dt>G97</dt><dd>0.532710215583802</dd><dt>G98</dt><dd>0.489140569280338</dd><dt>G99</dt><dd>0.66568090061631</dd><dt>G100</dt><dd>0.51512015532718</dd><dt>G102</dt><dd>0.539162586919637</dd><dt>G103</dt><dd>0.526091697462466</dd><dt>G104</dt><dd>0.539162586919637</dd><dt>G107</dt><dd>0.526091697462466</dd><dt>G108</dt><dd>0.532710215583802</dd><dt>G109</dt><dd>0.628626247022891</dd><dt>G110</dt><dd>0.536924116839172</dd><dt>G111</dt><dd>0.547585289014435</dd><dt>G112</dt><dd>0.644467558269549</dd><dt>G113</dt><dd>0.637496855980251</dd><dt>G114</dt><dd>0.460974547626375</dd><dt>G115</dt><dd>0.602988929901081</dd><dt>G117</dt><dd>0.501117144673946</dd><dt>G119</dt><dd>0.628626247022891</dd><dt>G120</dt><dd>0.51512015532718</dd><dt>G121</dt><dd>0.723634578326461</dd><dt>G122</dt><dd>4.2139776571396</dd><dt>G123</dt><dd>0.54795222126418</dd><dt>G124</dt><dd>0.702119809700844</dd><dt>G125</dt><dd>0.503315446773238</dd><dt>G126</dt><dd>0.484769370326196</dd><dt>G127</dt><dd>0.526091697462466</dd><dt>G128</dt><dd>0.501117144673946</dd><dt>G129</dt><dd>0.55651223346432</dd><dt>G130</dt><dd>0.715905602096421</dd><dt>G131</dt><dd>0.501117144673946</dd><dt>G132</dt><dd>0.451817369137871</dd><dt>G133</dt><dd>0.460974547626375</dd><dt>G134</dt><dd>0.440157701071704</dd><dt>G135</dt><dd>0.536924116839172</dd><dt>G137</dt><dd>0.637496855980251</dd><dt>G138</dt><dd>0.489140569280338</dd><dt>G139</dt><dd>0.578158941611559</dd><dt>G140</dt><dd>0.619505731338351</dd><dt>G142</dt><dd>0.460974547626375</dd><dt>G144</dt><dd>0.619505731338351</dd><dt>G145</dt><dd>0.71978988547883</dd><dt>G146</dt><dd>0.651785148853247</dd><dt>G147</dt><dd>0.723634578326461</dd><dt>G148</dt><dd>0.730044869559096</dd><dt>G149</dt><dd>0.489140569280338</dd><dt>G151</dt><dd>0.489140569280338</dd><dt>G152</dt><dd>0.672122665521609</dd><dt>G153</dt><dd>0.489140569280338</dd><dt>G154</dt><dd>0.51512015532718</dd><dt>G155</dt><dd>0.526091697462466</dd><dt>G156</dt><dd>0.563141863581101</dd><dt>G157</dt><dd>0.547585289014435</dd><dt>G158</dt><dd>0.501117144673946</dd><dt>G159</dt><dd>0.536924116839172</dd><dt>G160</dt><dd>0.526091697462466</dd><dt>G161</dt><dd>0.659433812767765</dd><dt>G162</dt><dd>0.52023746247388</dd><dt>G163</dt><dd>0.460974547626375</dd><dt>G164</dt><dd>0.653974641560693</dd><dt>G165</dt><dd>0.536924116839172</dd><dt>G166</dt><dd>0.51512015532718</dd><dt>G167</dt><dd>0.738160592570096</dd><dt>G168</dt><dd>0.539162586919637</dd><dt>G169</dt><dd>0.547585289014435</dd><dt>G170</dt><dd>0.51512015532718</dd><dt>G172</dt><dd>0.492680822431155</dd><dt>G173</dt><dd>0.471882421985132</dd><dt>G174</dt><dd>0.460974547626375</dd><dt>G175</dt><dd>0.619505731338351</dd><dt>G176</dt><dd>0.51512015532718</dd><dt>G177</dt><dd>0.547585289014435</dd><dt>G178</dt><dd>0.52023746247388</dd><dt>G179</dt><dd>0.539162586919637</dd><dt>G180</dt><dd>0.489140569280338</dd><dt>G181</dt><dd>0.653974641560693</dd><dt>G182</dt><dd>0.563141863581101</dd><dt>G183</dt><dd>0.602988929901081</dd><dt>G184</dt><dd>0.72616611863631</dd><dt>G185</dt><dd>0.451817369137871</dd><dt>G194</dt><dd>0.52023746247388</dd><dt>G195</dt><dd>0.501117144673946</dd><dt>G196</dt><dd>0.602988929901081</dd><dt>G197</dt><dd>0.440157701071704</dd><dt>G198</dt><dd>0.489140569280338</dd><dt>G199</dt><dd>0.451817369137871</dd><dt>G200</dt><dd>0.489140569280338</dd><dt>G201</dt><dd>0.547585289014435</dd><dt>G202</dt><dd>0.451246316612183</dd><dt>G203</dt><dd>0.51512015532718</dd><dt>G204</dt><dd>0.651785148853247</dd><dt>G205</dt><dd>0.471882421985132</dd><dt>G207</dt><dd>0.484769370326196</dd><dt>G208</dt><dd>0.460974547626375</dd><dt>G209</dt><dd>0.451817369137871</dd><dt>G210</dt><dd>0.52023746247388</dd><dt>G211</dt><dd>0.489140569280338</dd><dt>G213</dt><dd>0.51512015532718</dd><dt>G214</dt><dd>0.427341052978041</dd><dt>G215</dt><dd>0.451817369137871</dd><dt>G216</dt><dd>0.637496855980251</dd><dt>G217</dt><dd>0.644467558269549</dd><dt>G218</dt><dd>0.660382509325181</dd><dt>G219</dt><dd>0.52023746247388</dd><dt>G220</dt><dd>0.440157701071704</dd><dt>G221</dt><dd>0.532710215583802</dd><dt>G222</dt><dd>0.489140569280338</dd><dt>G223</dt><dd>0.51512015532718</dd><dt>G224</dt><dd>0.484769370326196</dd><dt>G225</dt><dd>0.727029845056381</dd><dt>G226</dt><dd>0.715905602096421</dd><dt>G227</dt><dd>0.725874479765876</dd><dt>G228</dt><dd>⋯</dd><dt>G229</dt><dd>0.532710215583802</dd><dt>G230</dt><dd>0.644467558269549</dd><dt>G231</dt><dd>0.502669045557482</dd><dt>G232</dt><dd>0.489140569280338</dd><dt>G234</dt><dd>0.489140569280338</dd><dt>G235</dt><dd>0.55651223346432</dd><dt>G236</dt><dd>0.52023746247388</dd><dt>G237</dt><dd>0.547585289014435</dd><dt>G238</dt><dd>0.501117144673946</dd><dt>G240</dt><dd>0.526091697462466</dd><dt>G241</dt><dd>0.55651223346432</dd><dt>G242</dt><dd>0.471882421985132</dd><dt>G243</dt><dd>0.489140569280338</dd><dt>G244</dt><dd>0.532710215583802</dd><dt>G245</dt><dd>0.681012369598666</dd><dt>G246</dt><dd>0.536924116839172</dd><dt>G247</dt><dd>0.628626247022891</dd><dt>G248</dt><dd>0.536924116839172</dd><dt>G249</dt><dd>0.539162586919637</dd><dt>G250</dt><dd>0.52023746247388</dd><dt>G251</dt><dd>0.602988929901081</dd><dt>G252</dt><dd>0.539162586919637</dd><dt>G254</dt><dd>0.723634578326461</dd><dt>G255</dt><dd>0.532710215583802</dd><dt>G256</dt><dd>0.602988929901081</dd><dt>G289</dt><dd>0.644467558269549</dd><dt>G290</dt><dd>0.536924116839172</dd><dt>G291</dt><dd>0.602988929901081</dd><dt>G292</dt><dd>0.715905602096421</dd><dt>G293</dt><dd>0.644467558269549</dd><dt>G294</dt><dd>0.628626247022891</dd><dt>G295</dt><dd>0.637496855980251</dd><dt>G296</dt><dd>0.578158941611559</dd><dt>G297</dt><dd>0.65922162114682</dd><dt>G298</dt><dd>0.563141863581101</dd><dt>G299</dt><dd>0.644467558269549</dd><dt>G300</dt><dd>0.637496855980251</dd><dt>G301</dt><dd>0.52023746247388</dd><dt>G302</dt><dd>0.501117144673946</dd><dt>G303</dt><dd>0.55651223346432</dd><dt>G304</dt><dd>0.563141863581101</dd><dt>G305</dt><dd>0.532710215583802</dd><dt>G306</dt><dd>0.651785148853247</dd><dt>G307</dt><dd>0.539162586919637</dd><dt>G308</dt><dd>0.602988929901081</dd><dt>G309</dt><dd>0.539162586919637</dd><dt>G310</dt><dd>0.628626247022891</dd><dt>G311</dt><dd>0.637496855980251</dd><dt>G312</dt><dd>0.578158941611559</dd><dt>G313</dt><dd>0.489140569280338</dd><dt>G314</dt><dd>0.501117144673946</dd><dt>G315</dt><dd>0.539162586919637</dd><dt>G317</dt><dd>0.859136950612951</dd><dt>G318</dt><dd>0.718585783430077</dd><dt>G319</dt><dd>0.672122665521609</dd><dt>G320</dt><dd>0.49895980328133</dd><dt>G321</dt><dd>0.653974641560693</dd><dt>G322</dt><dd>0.659433812767765</dd><dt>G323</dt><dd>0.563141863581101</dd><dt>G324</dt><dd>0.532710215583802</dd><dt>G325</dt><dd>1.11634944780743</dd><dt>G326</dt><dd>0.602988929901081</dd><dt>G327</dt><dd>0.526091697462466</dd><dt>G328</dt><dd>0.58760560894698</dd><dt>G329</dt><dd>0.677960568116856</dd><dt>G330</dt><dd>0.651785148853247</dd><dt>G331</dt><dd>0.859136950612951</dd><dt>G332</dt><dd>0.563141863581101</dd><dt>G333</dt><dd>0.602988929901081</dd><dt>G334</dt><dd>0.644467558269549</dd><dt>G335</dt><dd>0.51512015532718</dd><dt>G336</dt><dd>0.526091697462466</dd><dt>G337</dt><dd>0.743681530576145</dd><dt>G338</dt><dd>0.651785148853247</dd><dt>G339</dt><dd>0.637496855980251</dd><dt>G340</dt><dd>0.681012369598666</dd><dt>G342</dt><dd>0.619505731338351</dd><dt>G343</dt><dd>0.67115710321501</dd><dt>G345</dt><dd>0.632365162773237</dd><dt>G346</dt><dd>0.526091697462466</dd><dt>G347</dt><dd>0.628626247022891</dd><dt>G348</dt><dd>0.653974641560693</dd><dt>G349</dt><dd>0.681012369598666</dd><dt>G350</dt><dd>0.653974641560693</dd><dt>G351</dt><dd>0.637496855980251</dd><dt>G353</dt><dd>0.71978988547883</dd><dt>G354</dt><dd>0.489140569280338</dd><dt>G355</dt><dd>0.531041152091456</dd><dt>G356</dt><dd>0.877999786107551</dd><dt>G357</dt><dd>0.651785148853247</dd><dt>G358</dt><dd>0.602988929901081</dd><dt>G359</dt><dd>0.71978988547883</dd><dt>G360</dt><dd>0.55651223346432</dd><dt>S1</dt><dd>0.651785148853247</dd><dt>S2</dt><dd>0.563141863581101</dd><dt>S3</dt><dd>0.536924116839172</dd><dt>S4</dt><dd>0.602988929901081</dd><dt>S5</dt><dd>0.563141863581101</dd><dt>S6</dt><dd>0.578158941611559</dd><dt>S8</dt><dd>0.681012369598666</dd><dt>S10</dt><dd>0.651785148853247</dd><dt>S12</dt><dd>0.619505731338351</dd><dt>S13</dt><dd>0.595201933993623</dd><dt>S15</dt><dd>0.471882421985132</dd><dt>S17</dt><dd>0.440157701071704</dd><dt>S25</dt><dd>0.642783572244552</dd><dt>S28</dt><dd>0.619505731338351</dd><dt>S31</dt><dd>0.699066038539441</dd><dt>S35</dt><dd>0.52023746247388</dd><dt>S36</dt><dd>1.54510235593612</dd><dt>S37</dt><dd>0.526091697462466</dd><dt>S38</dt><dd>0.715905602096421</dd><dt>S39</dt><dd>0.503315446773238</dd><dt>S40</dt><dd>0.51512015532718</dd><dt>S41</dt><dd>0.563141863581101</dd><dt>S42</dt><dd>0.66568090061631</dd><dt>S48</dt><dd>8.00213495907961</dd><dt>S50</dt><dd>0.651994946807086</dd><dt>S54</dt><dd>0.484769370326196</dd><dt>S58</dt><dd>0.539162586919637</dd><dt>S62</dt><dd>0.651785148853247</dd><dt>S63</dt><dd>0.637496855980251</dd><dt>S64</dt><dd>0.573511132715367</dd><dt>S65</dt><dd>2.81983282950753</dd><dt>S66</dt><dd>0.78530332320992</dd><dt>S67</dt><dd>18.0707898810834</dd><dt>S68</dt><dd>8.96011678837242</dd><dt>S69</dt><dd>18.5468044758437</dd><dt>S70</dt><dd>28.8360537864389</dd><dt>S71</dt><dd>2.45488787412988</dd><dt>S72</dt><dd>16.4828360807601</dd><dt>S73</dt><dd>31.9808403023937</dd><dt>S74</dt><dd>34.6631762253358</dd><dt>S75</dt><dd>5.45702822413619</dd><dt>S76</dt><dd>3.61828655323153</dd><dt>S77</dt><dd>1.21493155147119</dd><dt>S78</dt><dd>1.69573549758185</dd><dt>S79</dt><dd>0.846002528765044</dd><dt>S80</dt><dd>0.628626247022891</dd><dt>S81</dt><dd>22.8421606950916</dd><dt>S82</dt><dd>12.5441382410788</dd><dt>S83</dt><dd>12.1030929982911</dd><dt>S84</dt><dd>0.926076874693225</dd><dt>S85</dt><dd>0.855855854240824</dd><dt>S86</dt><dd>1.94099486816678</dd><dt>S87</dt><dd>6.10799122361838</dd><dt>S88</dt><dd>0.738160592570096</dd><dt>S89</dt><dd>8.4343074676151</dd><dt>S90</dt><dd>47.8551045461257</dd><dt>S91</dt><dd>19.542578766802</dd><dt>S93</dt><dd>2.98239592011222</dd><dt>S94</dt><dd>0.651994946807086</dd><dt>S95</dt><dd>0.954280586236996</dd><dt>S96</dt><dd>1.97529075372161</dd><dt>S97</dt><dd>28.1458281886152</dd><dt>S98</dt><dd>0.74084136548925</dd><dt>S99</dt><dd>14.6396966814559</dd><dt>S100</dt><dd>6.60754914164576</dd><dt>S101</dt><dd>1.28673201815392</dd><dt>S102</dt><dd>7.00375904278842</dd><dt>S103</dt><dd>0.539162586919637</dd><dt>S104</dt><dd>31.5018684889688</dd><dt>S105</dt><dd>7.13416090062538</dd><dt>S106</dt><dd>30.166079042861</dd><dt>S107</dt><dd>31.6834235015257</dd><dt>S108</dt><dd>29.481477842155</dd><dt>S109</dt><dd>26.1628527813906</dd><dt>S110</dt><dd>2.06896999488609</dd><dt>S111</dt><dd>19.4187488990743</dd><dt>S112</dt><dd>0.604932997932187</dd><dt>S119</dt><dd>8.4182535090439</dd><dt>S121</dt><dd>7.20548799623964</dd><dt>S122</dt><dd>9.32620671226219</dd><dt>S123</dt><dd>1.99830232415751</dd><dt>S124</dt><dd>0.686753352983239</dd><dt>S125</dt><dd>6.97613729897351</dd><dt>S126</dt><dd>5.46995421733551</dd><dt>S127</dt><dd>5.22119696706262</dd><dt>S129</dt><dd>8.2503332053069</dd><dt>S130</dt><dd>7.65138616837024</dd><dt>S131</dt><dd>0.715905602096421</dd><dt>S132</dt><dd>0.727029845056381</dd><dt>S133</dt><dd>0.702119809700844</dd><dt>S134</dt><dd>0.738160592570096</dd><dt>S135</dt><dd>0.681012369598666</dd><dt>S137</dt><dd>0.672122665521609</dd><dt>S138</dt><dd>0.718585783430077</dd><dt>S139</dt><dd>0.526091697462466</dd><dt>S140</dt><dd>0.659433812767765</dd><dt>S142</dt><dd>2.89583581322522</dd><dt>S143</dt><dd>5.688859442237</dd><dt>S144</dt><dd>0.672122665521609</dd><dt>S147</dt><dd>1.97830143830329</dd><dt>S148</dt><dd>0.659433812767765</dd><dt>S149</dt><dd>0.532710215583802</dd><dt>S150</dt><dd>0.563141863581101</dd><dt>S151</dt><dd>0.51512015532718</dd><dt>S152</dt><dd>0.55651223346432</dd><dt>S153</dt><dd>0.535790116241828</dd><dt>S155</dt><dd>0.51512015532718</dd></dl>



    using pre-existing size factors
    
    estimating dispersions
    
    gene-wise dispersion estimates
    
    mean-dispersion relationship
    
    -- note: fitType='parametric', but the dispersion trend was not well captured by the
       function: y = a/x + b, and a local regression fit was automatically substituted.
       specify fitType='local' or 'mean' to avoid this message next time.
    
    final dispersion estimates
    
    fitting model and testing
    
    -- replacing outliers and refitting for 57 genes
    -- DESeq argument 'minReplicatesForReplace' = 7 
    -- original counts are preserved in counts(dds)
    
    estimating dispersions
    
    fitting model and testing
    
    

##### Gut samples clustering based on location and fish species visualized using an NMDS plot
###### https://jkzorz.github.io/2019/06/06/NMDS.html



```R

library(ggplot2) 
library(vegan)


Only_Gut <-read.table("Only_Gut.txt",header=T,  row.names = 1)

com = Only_Gut[,11:ncol(Only_Gut)]


m_com = as.matrix(com)


set.seed(123)
nmds = metaMDS(m_com, distance = "bray")
nmds


plot(nmds)




```

    Square root transformation
    Wisconsin double standardization
    Run 0 stress 0.2302727 
    Run 1 stress 0.238954 
    Run 2 stress 0.232866 
    Run 3 stress 0.2278034 
    ... New best solution
    ... Procrustes: rmse 0.02942826  max resid 0.2067819 
    Run 4 stress 0.2334689 
    Run 5 stress 0.2389854 
    Run 6 stress 0.2364733 
    Run 7 stress 0.2274815 
    ... New best solution
    ... Procrustes: rmse 0.0329838  max resid 0.2154993 
    Run 8 stress 0.2374154 
    Run 9 stress 0.2408066 
    Run 10 stress 0.2329656 
    Run 11 stress 0.2379002 
    Run 12 stress 0.2290857 
    Run 13 stress 0.2348691 
    Run 14 stress 0.2384654 
    Run 15 stress 0.2272331 
    ... New best solution
    ... Procrustes: rmse 0.02508402  max resid 0.2147911 
    Run 16 stress 0.2315922 
    Run 17 stress 0.2312511 
    Run 18 stress 0.2289841 
    Run 19 stress 0.2271704 
    ... New best solution
    ... Procrustes: rmse 0.02688158  max resid 0.2230439 
    Run 20 stress 0.2286337 
    *** Best solution was not repeated -- monoMDS stopping criteria:
         2: no. of iterations >= maxit
        16: stress ratio > sratmax
         2: scale factor of the gradient < sfgrmin
    


    
    Call:
    metaMDS(comm = m_com, distance = "bray") 
    
    global Multidimensional Scaling using monoMDS
    
    Data:     wisconsin(sqrt(m_com)) 
    Distance: bray 
    
    Dimensions: 2 
    Stress:     0.2271704 
    Stress type 1, weak ties
    Best solution was not repeated after 20 tries
    The best solution was from try 19 (random start)
    Scaling: centring, PC rotation, halfchange scaling 
    Species: expanded scores based on 'wisconsin(sqrt(m_com))' 
    



    
![png](output_12_2.png)
    


##### samples clustering based on location and fish species visualized using an NMDS plot
###### https://jkzorz.github.io/2019/06/06/NMDS.html


```R

Only_Skin <-read.table("Only_Skin.txt",header=T,  row.names = 1)

com = Only_Skin[,9:ncol(Only_Skin)]


m_com = as.matrix(com)

set.seed(123)
nmds = metaMDS(m_com, distance = "bray")

plot(nmds)


```

    Square root transformation
    Wisconsin double standardization
    Run 0 stress 0.2014788 
    Run 1 stress 0.2078746 
    Run 2 stress 0.2174766 
    Run 3 stress 0.2054918 
    Run 4 stress 0.1994072 
    ... New best solution
    ... Procrustes: rmse 0.01045777  max resid 0.1426117 
    Run 5 stress 0.199328 
    ... New best solution
    ... Procrustes: rmse 0.01379315  max resid 0.1832563 
    Run 6 stress 0.2011911 
    Run 7 stress 0.2076003 
    Run 8 stress 0.2059653 
    Run 9 stress 0.2047344 
    Run 10 stress 0.2084235 
    Run 11 stress 0.2078646 
    Run 12 stress 0.2082682 
    Run 13 stress 0.2133055 
    Run 14 stress 0.2011414 
    Run 15 stress 0.2131932 
    Run 16 stress 0.2117047 
    Run 17 stress 0.2039484 
    Run 18 stress 0.203322 
    Run 19 stress 0.2030166 
    Run 20 stress 0.2048603 
    *** Best solution was not repeated -- monoMDS stopping criteria:
        18: stress ratio > sratmax
         2: scale factor of the gradient < sfgrmin
    


    
![png](output_14_1.png)
    


## PERMANOVA analyses using adonis2 in vegan  (v.2.6-4) 
#### exploring the role of location, habitat, diet, host fish species, and interaction of fish species with sampling location for both gut and skin samples

#### Testing gut and skin samples 


```R
library(vegan)
data.Gut <-read.table("data.Gut.txt",header=T,  row.names = 1)
Env.Gut <-read.table("Env.Gut.txt",header=T,  row.names = 1)



Locations_F <- factor(Env.Gut$Locations, labels = c("Lake_Erie", "Lake_Ontario", "Detroit_River"))


Diet_F <- factor(Env.Gut$Diet_Classification, labels = c("A", "B", "C", "D"))


Fishname_F <- factor(Env.Gut$Fishname, labels = c("Freshwater_Drum", "Gizzard_Shad", "Pumpkinseed", "Rock_Bass", "Round_Goby", "Walleye", "White_Bass", "White_Perch", "White_Sucker", "Yellow_Perch"))

Habitats <- factor(Env.Gut$Habitats, labels = c("Pelagic", "Benthic", "Benthopelagic"))


Gut_Table3<-adonis2(data.Gut~ Locations + Fishname + Locations_F*Fishname_F + Habitats + Diet_Classification, data=Env.Gut, method="bray" , permutation=999)

Gut_Table3



data.Skin <-read.table("data.Skin.txt",header=T,  row.names = 1)
Env.Skin <-read.table("Env.Skin.txt",header=T,  row.names = 1)



Locations_F <- factor(Env.Skin$Locations, labels = c("Lake_Erie", "Lake_Ontario", "Detroit_River"))


Diet_F <- factor(Env.Skin$Diet, labels = c("Invertivore_carnivore", "Invertivore_detritivore", "Herbivore", "Invertivore"))


Fishname_F <- factor(Env.Skin$Fishname, labels = c("Freshwater_Drum", "Gizzard_Shad", "Pumpkinseed", "Rock_Bass", "Round_Goby", "Walleye", "White_Bass", "White_Perch", "White_Sucker", "Yellow_Perch"))

Habitats <- factor(Env.Skin$Habitats, labels = c("Pelagic", "Benthic", "Benthopelagic"))



Skin_Table3<-adonis2(data.Skin~ Locations_F + Fishname_F + Locations_F*Fishname_F + Habitats + Diet, data=Env.Skin, method="bray", permutation=999)

Skin_Table3


```


<table class="dataframe">
<caption>A anova.cca: 5 × 5</caption>
<thead>
	<tr><th></th><th scope=col>Df</th><th scope=col>SumOfSqs</th><th scope=col>R2</th><th scope=col>F</th><th scope=col>Pr(&gt;F)</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>Locations</th><td>  2</td><td>10.524238</td><td>0.13277987</td><td>17.083173</td><td>0.001</td></tr>
	<tr><th scope=row>Fishname</th><td>  9</td><td> 6.671919</td><td>0.08417679</td><td> 2.406668</td><td>0.001</td></tr>
	<tr><th scope=row>Locations_F:Fishname_F</th><td> 10</td><td> 6.311319</td><td>0.07962725</td><td> 2.048934</td><td>0.001</td></tr>
	<tr><th scope=row>Residual</th><td>181</td><td>55.753318</td><td>0.70341609</td><td>       NA</td><td>   NA</td></tr>
	<tr><th scope=row>Total</th><td>202</td><td>79.260795</td><td>1.00000000</td><td>       NA</td><td>   NA</td></tr>
</tbody>
</table>




<table class="dataframe">
<caption>A anova.cca: 5 × 5</caption>
<thead>
	<tr><th></th><th scope=col>Df</th><th scope=col>SumOfSqs</th><th scope=col>R2</th><th scope=col>F</th><th scope=col>Pr(&gt;F)</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>Locations_F</th><td>  2</td><td>15.239256</td><td>0.17587559</td><td>26.059284</td><td>0.001</td></tr>
	<tr><th scope=row>Fishname_F</th><td>  9</td><td> 5.949841</td><td>0.06866685</td><td> 2.260953</td><td>0.001</td></tr>
	<tr><th scope=row>Locations_F:Fishname_F</th><td> 10</td><td> 6.394861</td><td>0.07380281</td><td> 2.187056</td><td>0.001</td></tr>
	<tr><th scope=row>Residual</th><td>202</td><td>59.063972</td><td>0.68165475</td><td>       NA</td><td>   NA</td></tr>
	<tr><th scope=row>Total</th><td>223</td><td>86.647929</td><td>1.00000000</td><td>       NA</td><td>   NA</td></tr>
</tbody>
</table>



## LASSO (least absolute shrinkage and selection operator) regression glmnet package (v.4.1.7) to identify the variables and corresponding regression coefficients that lead to a model that minimizes the prediction error and perform variable selection 


```R
library(caret)
library(glmnet)
library(ggpubr)
library(RColorBrewer)



#########Upload the data 
Gut <- read.delim("LASSO.txt", sep = "\t", row.names = 1)

##set seeds
set.seed(1233)


##chao1
Gut$Weight <- Gut$Weight_Log_Transformed

#Split and create index matrix of selected values

index <- createDataPartition(Gut$chao1, p=.8, list = FALSE, times=1)

# creating test and trainning data frame

train_df <- Gut[index,]
test_df <- Gut[-index,]

#K-fold cross-validation (3 fold cross-validation)framework


# specify 3-fold cross-validation as training method (framework)

ctrlspecs <- trainControl(method = "cv", number=10,
                          savePredictions="all")


###specify & train LASSO Regression model

#Create vector of potential lambda values


lambda_vector <- 10^seq(5, -5, length=500)


#set seed

set.seed(1233)


###specify Lasso regression model to be estimated using training data 

# and 10 fold cross validation frame work process

model1 <- train(chao1 ~ Locations + Fishname + 
                  Diet + Habitats  + Weight , data=train_df,
                preProcess=c("center", "scale"), method="glmnet", tuneGrid=expand.grid(alpha=1, lambda=lambda_vector),
                trControl=ctrlspecs, na.action=na.omit)

##what was the optimal tuning paprameter (alpha, lambda)

model1$bestTune


###LASSO regression model coefficients (parameter estimates)

Rersultsofmodel1 <- round(coef(model1$finalModel, model1$bestTune$lambda), 3)


#plot log(lambda) and RMSE

plot(log(model1$results$lambda), model1$results$RMSE, xlab="loglamba", ylab = "RMSE",
     xlim = c(-4,3))

###predicted variables important

varImp(model1)

A <- ggplot((varImp(model1))) + geom_bar(stat = "identity", fill = "gray")






##shannon_entropy


##set seeds
set.seed(1233)




#Split and create index matrix of selected values

index <- createDataPartition(Gut$shannon_entropy, p=.8, list = FALSE, times=1)

# creating test and trainning data frame

train_df <- Gut[index,]
test_df <- Gut[-index,]

#K-fold cross-validation (3 fold cross-validation)framework


# specify 3-fold cross-validation as training method (framework)

ctrlspecs <- trainControl(method = "cv", number=10,
                          savePredictions="all")


###specify & train LASSO Regression model

#Create vector of potential lambda values


lambda_vector <- 10^seq(5, -5, length=500)


#set seed

set.seed(1233)

###specify Lasso regression model to be estimated using training data 

# and 10 fold cross validation frame work process

model2 <- train(shannon_entropy ~ Locations + Fishname + 
                  Diet + Habitats + Weight, data=train_df,
                preProcess=c("center", "scale"), method="glmnet", tuneGrid=expand.grid(alpha=1, lambda=lambda_vector),
                trControl=ctrlspecs, na.action=na.omit)

##what was the optimal tuning paprameter (alpha, lambda)

model2$bestTune


###LASSO regression model coefficients (parameter estimates)

model2results <- coef(model2$finalModel, model2$bestTune$lambda)
model2results


###predicted varibles important

varImp(model2)
B <- ggplot(varImp(model2)) + geom_bar(stat = "identity", fill = "gray")



#####log_PD

##set seeds
set.seed(1233)




#Split and create index matrix of selected values

index <- createDataPartition(Gut$log_PD, p=.8, list = FALSE, times=1)

# creating test and trainning data frame

train_df <- Gut[index,]
test_df <- Gut[-index,]

#K-fold cross-validation (3 fold cross-validation)framework


# specify 3-fold cross-validation as training method (framework)

ctrlspecs <- trainControl(method = "cv", number=10,
                          savePredictions="all")


###specify & train LASSO Regression model

#Create vector of potential lambda values


lambda_vector <- 10^seq(5, -5, length=500)


#set seed

set.seed(1233)

###specify Lasso regression model to be estimated using training data 

# and 10 fold cross validation frame work process

model3 <- train(log_PD ~ Locations + Fishname + 
                  Diet + Habitats + Weight , data=train_df,
                preProcess=c("center", "scale"), method="glmnet", tuneGrid=expand.grid(alpha=1, lambda=lambda_vector),
                trControl=ctrlspecs, na.action=na.omit)

##what was the optimal tuning paprameter (alpha, lambda)

model3$bestTune


###LASSO regression model coefficients (parameter estimates)

model3results <- coef(model3$finalModel, model3$bestTune$lambda)
model3results

###predicted varibles important

varImp(model3)
C <- ggplot(varImp(model3)) + geom_bar(stat = "identity", fill = "gray")




#########Axis.1
##set seeds
set.seed(1233)




#Split and create index matrix of selected values

index <- createDataPartition(Gut$Axis.1, p=.8, list = FALSE, times=1)

# creating test and trainning data frame

train_df <- Gut[index,]
test_df <- Gut[-index,]

#K-fold cross-validation (3 fold cross-validation)framework


# specify 3-fold cross-validation as training method (framework)

ctrlspecs <- trainControl(method = "cv", number=10,
                          savePredictions="all")


###specify & train LASSO Regression model

#Create vector of potential lambda values


lambda_vector <- 10^seq(5, -5, length=500)


#set seed

set.seed(1233)

###specify Lasso regression model to be estimated using training data 

# and 10 fold cross validation frame work process

model4 <- train(Axis.1 ~ Locations + Fishname + 
                  Diet + Habitats + Weight , data=train_df,
                preProcess=c("center", "scale"), method="glmnet", tuneGrid=expand.grid(alpha=1, lambda=lambda_vector),
                trControl=ctrlspecs, na.action=na.omit)

##what was the optimal tuning paprameter (alpha, lambda)

model4$bestTune


###LASSO regression model coefficients (parameter estimates)

model4Results <- coef(model4$finalModel, model4$bestTune$lambda)


model4Results

###predicted varibles important

varImp(model4)
D <- ggplot((varImp(model4))) + geom_bar(stat = "identity", fill = "gray")





#########Axis.2
##set seeds
set.seed(1233)




#Split and create index matrix of selected values

index <- createDataPartition(Gut$Axis.2, p=.8, list = FALSE, times=1)

# creating test and trainning data frame

train_df <- Gut[index,]
test_df <- Gut[-index,]

#K-fold cross-validation (3 fold cross-validation)framework


# specify 3-fold cross-validation as training method (framework)

ctrlspecs <- trainControl(method = "cv", number=10,
                          savePredictions="all")


###specify & train LASSO Regression model

#Create vector of potential lambda values


lambda_vector <- 10^seq(5, -5, length=500)


#set seed

set.seed(1233)

###specify Lasso regression model to be estimated using training data 

# and 10 fold cross validation frame work process

model5 <- train(Axis.2 ~ Locations + Fishname + 
                  Diet + Habitats + Weight , data=train_df,
                preProcess=c("center", "scale"), method="glmnet", tuneGrid=expand.grid(alpha=1, lambda=lambda_vector),
                trControl=ctrlspecs, na.action=na.omit)

##what was the optimal tuning paprameter (alpha, lambda)

model5$bestTune


###LASSO regression model coefficients (parameter estimates)

model5Results <- coef(model5$finalModel, model5$bestTune$lambda)

model5Results

###predicted varibles important

varImp(model5)
E <- ggplot(varImp(model5)) + geom_bar(stat = "identity", fill = "gray")







#########Axis.3
##set seeds
set.seed(1233)




#Split and create index matrix of selected values

index <- createDataPartition(Gut$Axis.3, p=.8, list = FALSE, times=1)

# creating test and trainning data frame

train_df <- Gut[index,]
test_df <- Gut[-index,]

#K-fold cross-validation (3 fold cross-validation)framework


# specify 3-fold cross-validation as training method (framework)

ctrlspecs <- trainControl(method = "cv", number=10,
                          savePredictions="all")


###specify & train LASSO Regression model

#Create vector of potential lambda values


lambda_vector <- 10^seq(5, -5, length=500)


#set seed

set.seed(1233)

###specify Lasso regression model to be estimated using training data 

# and 10 fold cross validation frame work process

model6 <- train(Axis.3 ~ Locations + Fishname + 
                  Diet + Habitats + Weight , data=train_df,
                preProcess=c("center", "scale"), method="glmnet", tuneGrid=expand.grid(alpha=1, lambda=lambda_vector),
                trControl=ctrlspecs, na.action=na.omit)

##what was the optimal tuning paprameter (alpha, lambda)

model6$bestTune


###LASSO regression model coefficients (parameter estimates)

model6Result <- coef(model6$finalModel, model6$bestTune$lambda)

model6Result

###predicted varibles important

varImp(model6)
F1 <- ggplot(varImp(model6)) + geom_bar(stat = "identity", fill = "gray")










#########Axis.4
##set seeds
set.seed(1233)




#Split and create index matrix of selected values

index <- createDataPartition(Gut$Axis.4, p=.8, list = FALSE, times=1)

# creating test and trainning data frame

train_df <- Gut[index,]
test_df <- Gut[-index,]

#K-fold cross-validation (3 fold cross-validation)framework


# specify 3-fold cross-validation as training method (framework)

ctrlspecs <- trainControl(method = "cv", number=10,
                          savePredictions="all")


###specify & train LASSO Regression model

#Create vector of potential lambda values


lambda_vector <- 10^seq(5, -5, length=500)


#set seed

set.seed(1233)

###specify Lasso regression model to be estimated using training data 

# and 10 fold cross validation frame work process

model7 <- train(Axis.4 ~ Locations + Fishname + 
                  Diet + Habitats + Weight , data=train_df,
                preProcess=c("center", "scale"), method="glmnet", tuneGrid=expand.grid(alpha=1, lambda=lambda_vector),
                trControl=ctrlspecs, na.action=na.omit)

##what was the optimal tuning paprameter (alpha, lambda)

model7$bestTune


###LASSO regression model coefficients (parameter estimates)

model7Results <- coef(model7$finalModel, model7$bestTune$lambda)




###predicted varibles important

varImp(model7)
G <- ggplot((varImp(model7))) + geom_bar(stat = "identity", fill = "gray")







#########Axis.5
##set seeds
set.seed(1233)




#Split and create index matrix of selected values

index <- createDataPartition(Gut$Axis.5, p=.8, list = FALSE, times=1)

# creating test and trainning data frame

train_df <- Gut[index,]
test_df <- Gut[-index,]

#K-fold cross-validation (3 fold cross-validation)framework


# specify 3-fold cross-validation as training method (framework)

ctrlspecs <- trainControl(method = "cv", number=10,
                          savePredictions="all")


###specify & train LASSO Regression model

#Create vector of potential lambda values


lambda_vector <- 10^seq(5, -5, length=500)


#set seed

set.seed(1233)

###specify Lasso regression model to be estimated using training data 

# and 10 fold cross validation frame work process

model8 <- train(Axis.5 ~ Locations + Fishname + 
                  Diet + Habitats + Weight , data=train_df,
                preProcess=c("center", "scale"), method="glmnet", tuneGrid=expand.grid(alpha=1, lambda=lambda_vector),
                trControl=ctrlspecs, na.action=na.omit)

##what was the optimal tuning paprameter (alpha, lambda)

model8$bestTune


###LASSO regression model coefficients (parameter estimates)

model8Results <- coef(model8$finalModel, model8$bestTune$lambda)





###predicted varibles important

varImp(model8)
H <- ggplot((varImp(model8))) + geom_bar(stat = "identity", fill = "gray") 




overall <- ggarrange(B, A, C, D, E, F1, G, H, ncol=2, nrow=4) 
overall



Rersultsofmodel1
model2results
model3results
model4Results
model5Results
model6Result
model7Results
model8Results


```

    Loading required package: ggplot2
    
    
    Attaching package: 'caret'
    
    
    The following object is masked from 'package:vegan':
    
        tolerance
    
    
    Loading required package: Matrix
    
    Loaded glmnet 4.1-7
    
    Warning message in nominalTrainWorkflow(x = x, y = y, wts = weights, info = trainInfo, :
    "There were missing values in resampled performance measures."
    


<table class="dataframe">
<caption>A data.frame: 1 × 2</caption>
<thead>
	<tr><th></th><th scope=col>alpha</th><th scope=col>lambda</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>283</th><td>1</td><td>4.480254</td></tr>
</tbody>
</table>




    glmnet variable importance
    
              Overall
    Diet       100.00
    Locations   56.96
    Fishname     0.00
    Weight       0.00
    Habitats     0.00


    Warning message in nominalTrainWorkflow(x = x, y = y, wts = weights, info = trainInfo, :
    "There were missing values in resampled performance measures."
    


<table class="dataframe">
<caption>A data.frame: 1 × 2</caption>
<thead>
	<tr><th></th><th scope=col>alpha</th><th scope=col>lambda</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>181</th><td>1</td><td>0.04047757</td></tr>
</tbody>
</table>




    6 x 1 sparse Matrix of class "dgCMatrix"
                         s1
    (Intercept)  4.66688469
    Locations   -0.12820396
    Fishname     .         
    Diet        -0.14341554
    Habitats    -0.05571339
    Weight      -0.02920391



    glmnet variable importance
    
              Overall
    Diet       100.00
    Locations   89.39
    Habitats    38.85
    Weight      20.36
    Fishname     0.00


    Warning message in nominalTrainWorkflow(x = x, y = y, wts = weights, info = trainInfo, :
    "There were missing values in resampled performance measures."
    


<table class="dataframe">
<caption>A data.frame: 1 × 2</caption>
<thead>
	<tr><th></th><th scope=col>alpha</th><th scope=col>lambda</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>134</th><td>1</td><td>0.004627332</td></tr>
</tbody>
</table>




    6 x 1 sparse Matrix of class "dgCMatrix"
                         s1
    (Intercept)  1.17865546
    Locations   -0.05511944
    Fishname     .         
    Diet        -0.02190197
    Habitats    -0.02939769
    Weight      -0.02723549



    glmnet variable importance
    
              Overall
    Locations  100.00
    Habitats    53.33
    Weight      49.41
    Diet        39.74
    Fishname     0.00


    Warning message in nominalTrainWorkflow(x = x, y = y, wts = weights, info = trainInfo, :
    "There were missing values in resampled performance measures."
    


<table class="dataframe">
<caption>A data.frame: 1 × 2</caption>
<thead>
	<tr><th></th><th scope=col>alpha</th><th scope=col>lambda</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>209</th><td>1</td><td>0.1473454</td></tr>
</tbody>
</table>




    6 x 1 sparse Matrix of class "dgCMatrix"
                         s1
    (Intercept)   0.2853709
    Locations   -15.2381356
    Fishname      4.0368484
    Diet          2.6137757
    Habitats     -0.6367693
    Weight       -4.2371755



    glmnet variable importance
    
              Overall
    Locations  100.00
    Weight      24.66
    Fishname    23.29
    Diet        13.54
    Habitats     0.00


    Warning message in nominalTrainWorkflow(x = x, y = y, wts = weights, info = trainInfo, :
    "There were missing values in resampled performance measures."
    


<table class="dataframe">
<caption>A data.frame: 1 × 2</caption>
<thead>
	<tr><th></th><th scope=col>alpha</th><th scope=col>lambda</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>155</th><td>1</td><td>0.01219473</td></tr>
</tbody>
</table>




    6 x 1 sparse Matrix of class "dgCMatrix"
                         s1
    (Intercept)  0.05188372
    Locations    3.38275112
    Fishname     3.67187786
    Diet        -2.34613737
    Habitats     2.75291441
    Weight       1.80232270



    glmnet variable importance
    
              Overall
    Fishname   100.00
    Locations   84.53
    Habitats    50.85
    Diet        29.09
    Weight       0.00


    Warning message in nominalTrainWorkflow(x = x, y = y, wts = weights, info = trainInfo, :
    "There were missing values in resampled performance measures."
    


<table class="dataframe">
<caption>A data.frame: 1 × 2</caption>
<thead>
	<tr><th></th><th scope=col>alpha</th><th scope=col>lambda</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>500</th><td>1</td><td>1e+05</td></tr>
</tbody>
</table>




    6 x 1 sparse Matrix of class "dgCMatrix"
                        s1
    (Intercept) -0.1715603
    Locations    .        
    Fishname     .        
    Diet         .        
    Habitats     .        
    Weight       .        


    Warning message in FUN(newX[, i], ...):
    "no non-missing arguments to max; returning -Inf"
    Warning message in FUN(newX[, i], ...):
    "no non-missing arguments to max; returning -Inf"
    Warning message in FUN(newX[, i], ...):
    "no non-missing arguments to max; returning -Inf"
    Warning message in FUN(newX[, i], ...):
    "no non-missing arguments to max; returning -Inf"
    Warning message in FUN(newX[, i], ...):
    "no non-missing arguments to max; returning -Inf"
    


    glmnet variable importance
    
              Overall
    Locations     NaN
    Habitats      NaN
    Weight        NaN
    Diet          NaN
    Fishname      NaN


    Warning message in FUN(newX[, i], ...):
    "no non-missing arguments to max; returning -Inf"
    Warning message in FUN(newX[, i], ...):
    "no non-missing arguments to max; returning -Inf"
    Warning message in FUN(newX[, i], ...):
    "no non-missing arguments to max; returning -Inf"
    Warning message in FUN(newX[, i], ...):
    "no non-missing arguments to max; returning -Inf"
    Warning message in FUN(newX[, i], ...):
    "no non-missing arguments to max; returning -Inf"
    Warning message in nominalTrainWorkflow(x = x, y = y, wts = weights, info = trainInfo, :
    "There were missing values in resampled performance measures."
    


<table class="dataframe">
<caption>A data.frame: 1 × 2</caption>
<thead>
	<tr><th></th><th scope=col>alpha</th><th scope=col>lambda</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>152</th><td>1</td><td>0.01061823</td></tr>
</tbody>
</table>




    glmnet variable importance
    
              Overall
    Weight    100.000
    Habitats   43.174
    Fishname   16.908
    Locations   1.553
    Diet        0.000


    Warning message in nominalTrainWorkflow(x = x, y = y, wts = weights, info = trainInfo, :
    "There were missing values in resampled performance measures."
    


<table class="dataframe">
<caption>A data.frame: 1 × 2</caption>
<thead>
	<tr><th></th><th scope=col>alpha</th><th scope=col>lambda</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>151</th><td>1</td><td>0.01013939</td></tr>
</tbody>
</table>




    glmnet variable importance
    
              Overall
    Locations  100.00
    Weight      34.94
    Diet        26.09
    Fishname    16.88
    Habitats     0.00


    Warning message:
    "[1m[22mRemoved 5 rows containing missing values (`position_stack()`)."
    Warning message:
    "[1m[22mRemoved 5 rows containing missing values (`position_stack()`)."
    


    
![png](output_18_31.png)
    



    6 x 1 sparse Matrix of class "dgCMatrix"
                     s1
    (Intercept) 101.550
    Locations    -8.945
    Fishname      .    
    Diet        -15.704
    Habitats      .    
    Weight        .    



    6 x 1 sparse Matrix of class "dgCMatrix"
                         s1
    (Intercept)  4.66688469
    Locations   -0.12820396
    Fishname     .         
    Diet        -0.14341554
    Habitats    -0.05571339
    Weight      -0.02920391



    6 x 1 sparse Matrix of class "dgCMatrix"
                         s1
    (Intercept)  1.17865546
    Locations   -0.05511944
    Fishname     .         
    Diet        -0.02190197
    Habitats    -0.02939769
    Weight      -0.02723549



    6 x 1 sparse Matrix of class "dgCMatrix"
                         s1
    (Intercept)   0.2853709
    Locations   -15.2381356
    Fishname      4.0368484
    Diet          2.6137757
    Habitats     -0.6367693
    Weight       -4.2371755



    6 x 1 sparse Matrix of class "dgCMatrix"
                         s1
    (Intercept)  0.05188372
    Locations    3.38275112
    Fishname     3.67187786
    Diet        -2.34613737
    Habitats     2.75291441
    Weight       1.80232270



    6 x 1 sparse Matrix of class "dgCMatrix"
                        s1
    (Intercept) -0.1715603
    Locations    .        
    Fishname     .        
    Diet         .        
    Habitats     .        
    Weight       .        



    6 x 1 sparse Matrix of class "dgCMatrix"
                        s1
    (Intercept) -0.2175567
    Locations    1.1342851
    Fishname     1.5687656
    Diet        -1.0903395
    Habitats    -2.3119518
    Weight      -3.9198563



    6 x 1 sparse Matrix of class "dgCMatrix"
                        s1
    (Intercept) -0.1223843
    Locations    6.8323214
    Fishname     2.2890246
    Diet         2.7928130
    Habitats    -1.3665931
    Weight      -3.2765625



    
![png](output_18_40.png)
    


## To explore fish species, diet and habitat preference effects on gut and skin bacterial community composition (alpha (Shannon entropy, Chao1 and PD) and beta diversity indices (PCoA1-5)) several linear mixed-model (LMM) models were built in R (v.4.1.0) using the lme4 (55) package with fish species, habitat, diet, and weight as fixed factors and location as a random factor. For selecting the best model for each diversity index, we used AICcmodavg package (v. 2.3.2) (56) in R (v.4.3.1) using Akaike Information Criterion (AIC) after building the models.

##### *Only for chao1 in gut samples is shown in here but other diversity indeces are the same*


```R
library(lme4)
library(lmerTest)
library(huxtable)
library(dplyr)
library(broom)
library(pbkrtest)
library(emmeans)
library(AICcmodavg)




Gut <- read.delim("LMM.txt", sep = "\t", row.names = 1)

Gut$Locations<- as.factor(Gut$Locations)
Gut$Fishname<- as.factor(Gut$Fishname)
Gut$Habitats<- as.factor(Gut$Habitats)
Gut$Diet<- as.factor(Gut$Diet)
Gut$Weight<- as.factor(Gut$Weight)

boxplot(Chao1~ Habitats, data = Gut)
boxplot(Chao1~  Diet, data = Gut)
boxplot(Chao1~  Fishname , data = Gut)




Chao1Lmm20 <- lmer(Chao1~  Habitats + Diet + Fishname + Weight +
                     Habitats * Diet + Habitats * Fishname + Habitats * Weight + Diet * Fishname + Diet * Weight + Fishname * Weight + (1|Locations) , REML = FALSE, data = Gut)


###Taking out the last interaction
Chao1Lmm19 <- lmer(Chao1~  Habitats + Diet + Fishname + Weight +
                     Habitats * Diet + Habitats * Fishname + Habitats * Weight + Diet * Fishname + Diet * Weight  + (1|Locations) , REML = FALSE, data = Gut)


anova(Chao1Lmm20, Chao1Lmm19)


###So do not take out the last interation as model20 was better take the next one 




Chao1Lmm18 <- lmer(Chao1~  Habitats + Diet + Fishname + Weight +
                     Habitats * Diet + Habitats * Fishname + Habitats * Weight + Diet * Fishname  + Fishname * Weight + (1|Locations) , REML = FALSE, data = Gut)


anova(Chao1Lmm20, Chao1Lmm18)



###Did not improve the model so take model 18 and take out the next interactions 



Chao1Lmm17 <- lmer(Chao1~  Habitats + Diet + Fishname + Weight +
                     Habitats * Diet + Habitats * Fishname + Habitats * Weight +  Fishname * Weight + (1|Locations) , REML = FALSE, data = Gut)


anova(Chao1Lmm20, Chao1Lmm17)




###Did not improve the model so take model 18 and take out the next interactions 



Chao1Lmm16 <- lmer(Chao1~  Habitats + Diet + Fishname + Weight +
                     Habitats * Diet + Habitats * Fishname  +  Fishname * Weight + (1|Locations) , REML = FALSE, data = Gut)


anova(Chao1Lmm20, Chao1Lmm16)



###Did not improve the model so take model 18 and take out the next interactions 





Chao1Lmm15 <- lmer(Chao1~  Habitats + Diet + Fishname + Weight +
                     Habitats * Diet +  Fishname * Weight + (1|Locations) , REML = FALSE, data = Gut)


anova(Chao1Lmm20, Chao1Lmm15)


###Did not improve the model so take model 18 and take out the next interactions 



Chao1Lmm14 <- lmer(Chao1~  Habitats + Diet + Fishname + Weight  +  Fishname * Weight + (1|Locations) , REML = FALSE, data = Gut)

anova(Chao1Lmm20, Chao1Lmm14)


###Did not improve the model so take model 18 and take out the next interactions 

Chao1Lmm13 <- lmer(Chao1~  Habitats  + Fishname + Weight  +  Fishname * Weight + (1|Locations) , REML = FALSE, data = Gut)

anova(Chao1Lmm20, Chao1Lmm13)


###Did not improve the model so take model 18 and take out the next interactions 

Chao1Lmm12 <- lmer(Chao1~  Fishname + Weight  +  Fishname * Weight + (1|Locations) , REML = FALSE, data = Gut)


anova(Chao1Lmm20, Chao1Lmm12)



Chao1Lmm11 <- lmer(Chao1~  Fishname + (1|Locations) , REML = FALSE, data = Gut)

anova(Chao1Lmm11)

Chao1Lmm10 <- lmer(Chao1~  Fishname + Weight + (1|Locations) , REML = FALSE, data = Gut)

Chao1Lmm9 <- lmer(Chao1~  Weight + (1|Locations) , REML = FALSE, data = Gut)

Chao1Lmm8 <- lmer(Chao1~  Habitats  + Fishname + Weight  +  Diet + (1|Locations) , REML = FALSE, data = Gut)

Chao1Lmm7 <- lmer(Chao1~  Habitats  + Fishname  + (1|Locations) , REML = FALSE, data = Gut)
anova(Chao1Lmm7)

Chao1Lmm6 <- lmer(Chao1~  Habitats  + Diet  + (1|Locations) + (1|Fishname), REML = FALSE, data = Gut)
anova(Chao1Lmm6)





anova(Chao1Lmm20, Chao1Lmm19, Chao1Lmm18, Chao1Lmm17, Chao1Lmm16, Chao1Lmm15, Chao1Lmm14, Chao1Lmm13, Chao1Lmm12, Chao1Lmm11, Chao1Lmm10, Chao1Lmm9)



Chao1_models <- list(Chao1Lmm20, Chao1Lmm19, Chao1Lmm18, Chao1Lmm17, Chao1Lmm16, Chao1Lmm15, Chao1Lmm14, Chao1Lmm13, Chao1Lmm12, Chao1Lmm11, Chao1Lmm10, Chao1Lmm9, Chao1Lmm8, Chao1Lmm7, Chao1Lmm6)

Chao1_model.names <- c("Chao1Lmm20", "Chao1Lmm19", "Chao1Lmm18", "Chao1Lmm17", "Chao1Lmm16", "Chao1Lmm15", "Chao1Lmm14", "Chao1Lmm13", "Chao1Lmm12", "Chao1Lmm11", "Chao1Lmm10", "Chao1Lmm9", "Chao1Lmm8", "Chao1Lmm7", "Chao1Lmm6")


aictab(cand.set = Chao1_models, modnames = Chao1_model.names)





```


    
![png](output_20_0.png)
    



    
![png](output_20_1.png)
    


    fixed-effect model matrix is rank deficient so dropping 4582 columns / coefficients
    
    boundary (singular) fit: see help('isSingular')
    
    fixed-effect model matrix is rank deficient so dropping 1593 columns / coefficients
    
    boundary (singular) fit: see help('isSingular')
    
    


<table class="dataframe">
<caption>A anova: 2 × 8</caption>
<thead>
	<tr><th></th><th scope=col>npar</th><th scope=col>AIC</th><th scope=col>BIC</th><th scope=col>logLik</th><th scope=col>deviance</th><th scope=col>Chisq</th><th scope=col>Df</th><th scope=col>Pr(&gt;Chisq)</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>Chao1Lmm19</th><td>203</td><td>110.01007</td><td>859.1530</td><td>147.9950</td><td>-295.9899</td><td>      NA</td><td>NA</td><td>          NA</td></tr>
	<tr><th scope=row>Chao1Lmm20</th><td>216</td><td> 96.00274</td><td>893.1204</td><td>167.9986</td><td>-335.9973</td><td>40.00733</td><td>13</td><td>0.0001378605</td></tr>
</tbody>
</table>



    fixed-effect model matrix is rank deficient so dropping 3476 columns / coefficients
    
    boundary (singular) fit: see help('isSingular')
    
    


<table class="dataframe">
<caption>A anova: 2 × 8</caption>
<thead>
	<tr><th></th><th scope=col>npar</th><th scope=col>AIC</th><th scope=col>BIC</th><th scope=col>logLik</th><th scope=col>deviance</th><th scope=col>Chisq</th><th scope=col>Df</th><th scope=col>Pr(&gt;Chisq)</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>Chao1Lmm20</th><td>216</td><td>96.00274</td><td>893.1204</td><td>167.9986</td><td>-335.9973</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><th scope=row>Chao1Lmm18</th><td>216</td><td>96.00274</td><td>893.1204</td><td>167.9986</td><td>-335.9973</td><td> 0</td><td> 0</td><td>NA</td></tr>
</tbody>
</table>



    fixed-effect model matrix is rank deficient so dropping 3343 columns / coefficients
    
    boundary (singular) fit: see help('isSingular')
    
    


<table class="dataframe">
<caption>A anova: 2 × 8</caption>
<thead>
	<tr><th></th><th scope=col>npar</th><th scope=col>AIC</th><th scope=col>BIC</th><th scope=col>logLik</th><th scope=col>deviance</th><th scope=col>Chisq</th><th scope=col>Df</th><th scope=col>Pr(&gt;Chisq)</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>Chao1Lmm20</th><td>216</td><td>96.00274</td><td>893.1204</td><td>167.9986</td><td>-335.9973</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><th scope=row>Chao1Lmm17</th><td>216</td><td>96.00274</td><td>893.1204</td><td>167.9986</td><td>-335.9973</td><td> 0</td><td> 0</td><td>NA</td></tr>
</tbody>
</table>



    fixed-effect model matrix is rank deficient so dropping 3027 columns / coefficients
    
    boundary (singular) fit: see help('isSingular')
    
    


<table class="dataframe">
<caption>A anova: 2 × 8</caption>
<thead>
	<tr><th></th><th scope=col>npar</th><th scope=col>AIC</th><th scope=col>BIC</th><th scope=col>logLik</th><th scope=col>deviance</th><th scope=col>Chisq</th><th scope=col>Df</th><th scope=col>Pr(&gt;Chisq)</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>Chao1Lmm20</th><td>216</td><td>96.00274</td><td>893.1204</td><td>167.9986</td><td>-335.9973</td><td>          NA</td><td>NA</td><td>NA</td></tr>
	<tr><th scope=row>Chao1Lmm16</th><td>216</td><td>96.00274</td><td>893.1204</td><td>167.9986</td><td>-335.9973</td><td>5.115908e-13</td><td> 0</td><td>NA</td></tr>
</tbody>
</table>



    fixed-effect model matrix is rank deficient so dropping 2989 columns / coefficients
    
    boundary (singular) fit: see help('isSingular')
    
    


<table class="dataframe">
<caption>A anova: 2 × 8</caption>
<thead>
	<tr><th></th><th scope=col>npar</th><th scope=col>AIC</th><th scope=col>BIC</th><th scope=col>logLik</th><th scope=col>deviance</th><th scope=col>Chisq</th><th scope=col>Df</th><th scope=col>Pr(&gt;Chisq)</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>Chao1Lmm20</th><td>216</td><td>96.00274</td><td>893.1204</td><td>167.9986</td><td>-335.9973</td><td>          NA</td><td>NA</td><td>NA</td></tr>
	<tr><th scope=row>Chao1Lmm15</th><td>216</td><td>96.00274</td><td>893.1204</td><td>167.9986</td><td>-335.9973</td><td>5.115908e-13</td><td> 0</td><td>NA</td></tr>
</tbody>
</table>



    fixed-effect model matrix is rank deficient so dropping 2975 columns / coefficients
    
    boundary (singular) fit: see help('isSingular')
    
    


<table class="dataframe">
<caption>A anova: 2 × 8</caption>
<thead>
	<tr><th></th><th scope=col>npar</th><th scope=col>AIC</th><th scope=col>BIC</th><th scope=col>logLik</th><th scope=col>deviance</th><th scope=col>Chisq</th><th scope=col>Df</th><th scope=col>Pr(&gt;Chisq)</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>Chao1Lmm20</th><td>216</td><td>96.00274</td><td>893.1204</td><td>167.9986</td><td>-335.9973</td><td>          NA</td><td>NA</td><td>NA</td></tr>
	<tr><th scope=row>Chao1Lmm14</th><td>216</td><td>96.00274</td><td>893.1204</td><td>167.9986</td><td>-335.9973</td><td>5.115908e-13</td><td> 0</td><td>NA</td></tr>
</tbody>
</table>



    fixed-effect model matrix is rank deficient so dropping 2968 columns / coefficients
    
    boundary (singular) fit: see help('isSingular')
    
    


<table class="dataframe">
<caption>A anova: 2 × 8</caption>
<thead>
	<tr><th></th><th scope=col>npar</th><th scope=col>AIC</th><th scope=col>BIC</th><th scope=col>logLik</th><th scope=col>deviance</th><th scope=col>Chisq</th><th scope=col>Df</th><th scope=col>Pr(&gt;Chisq)</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>Chao1Lmm20</th><td>216</td><td>96.00274</td><td>893.1204</td><td>167.9986</td><td>-335.9973</td><td>          NA</td><td>NA</td><td>NA</td></tr>
	<tr><th scope=row>Chao1Lmm13</th><td>216</td><td>96.00274</td><td>893.1204</td><td>167.9986</td><td>-335.9973</td><td>2.273737e-13</td><td> 0</td><td>NA</td></tr>
</tbody>
</table>



    fixed-effect model matrix is rank deficient so dropping 2966 columns / coefficients
    
    boundary (singular) fit: see help('isSingular')
    
    


<table class="dataframe">
<caption>A anova: 2 × 8</caption>
<thead>
	<tr><th></th><th scope=col>npar</th><th scope=col>AIC</th><th scope=col>BIC</th><th scope=col>logLik</th><th scope=col>deviance</th><th scope=col>Chisq</th><th scope=col>Df</th><th scope=col>Pr(&gt;Chisq)</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>Chao1Lmm20</th><td>216</td><td>96.00274</td><td>893.1204</td><td>167.9986</td><td>-335.9973</td><td>          NA</td><td>NA</td><td>NA</td></tr>
	<tr><th scope=row>Chao1Lmm12</th><td>216</td><td>96.00274</td><td>893.1204</td><td>167.9986</td><td>-335.9973</td><td>2.273737e-13</td><td> 0</td><td>NA</td></tr>
</tbody>
</table>



    boundary (singular) fit: see help('isSingular')
    
    


<table class="dataframe">
<caption>A anova: 1 × 6</caption>
<thead>
	<tr><th></th><th scope=col>Sum Sq</th><th scope=col>Mean Sq</th><th scope=col>NumDF</th><th scope=col>DenDF</th><th scope=col>F value</th><th scope=col>Pr(&gt;F)</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>Fishname</th><td>5.354968</td><td>0.2818404</td><td>19</td><td>296</td><td>4.507204</td><td>5.365999e-09</td></tr>
</tbody>
</table>



    fixed-effect model matrix is rank deficient so dropping 3 columns / coefficients
    
    boundary (singular) fit: see help('isSingular')
    
    boundary (singular) fit: see help('isSingular')
    
    fixed-effect model matrix is rank deficient so dropping 12 columns / coefficients
    
    boundary (singular) fit: see help('isSingular')
    
    fixed-effect model matrix is rank deficient so dropping 2 columns / coefficients
    
    boundary (singular) fit: see help('isSingular')
    
    


<table class="dataframe">
<caption>A anova: 2 × 6</caption>
<thead>
	<tr><th></th><th scope=col>Sum Sq</th><th scope=col>Mean Sq</th><th scope=col>NumDF</th><th scope=col>DenDF</th><th scope=col>F value</th><th scope=col>Pr(&gt;F)</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>Habitats</th><td>1.032820</td><td>0.5164101</td><td> 2</td><td>296</td><td>8.258454</td><td>3.235137e-04</td></tr>
	<tr><th scope=row>Fishname</th><td>4.719988</td><td>0.2776464</td><td>17</td><td>296</td><td>4.440133</td><td>3.337612e-08</td></tr>
</tbody>
</table>



    boundary (singular) fit: see help('isSingular')
    
    


<table class="dataframe">
<caption>A anova: 2 × 6</caption>
<thead>
	<tr><th></th><th scope=col>Sum Sq</th><th scope=col>Mean Sq</th><th scope=col>NumDF</th><th scope=col>DenDF</th><th scope=col>F value</th><th scope=col>Pr(&gt;F)</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>Habitats</th><td>0.8970493</td><td>0.4485246</td><td>2</td><td>21.35645</td><td>6.732020</td><td>0.0054069297</td></tr>
	<tr><th scope=row>Diet</th><td>2.4717415</td><td>0.3531059</td><td>7</td><td>27.69070</td><td>5.299856</td><td>0.0006282999</td></tr>
</tbody>
</table>




<table class="dataframe">
<caption>A anova: 12 × 8</caption>
<thead>
	<tr><th></th><th scope=col>npar</th><th scope=col>AIC</th><th scope=col>BIC</th><th scope=col>logLik</th><th scope=col>deviance</th><th scope=col>Chisq</th><th scope=col>Df</th><th scope=col>Pr(&gt;Chisq)</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>Chao1Lmm11</th><td> 22</td><td> 63.47257</td><td>144.6605</td><td> -9.736286</td><td>  19.47257</td><td>          NA</td><td> NA</td><td>          NA</td></tr>
	<tr><th scope=row>Chao1Lmm9</th><td>161</td><td>180.90548</td><td>775.0534</td><td> 70.547258</td><td>-141.09452</td><td>1.605671e+02</td><td>139</td><td>1.017606e-01</td></tr>
	<tr><th scope=row>Chao1Lmm10</th><td>177</td><td>158.44384</td><td>811.6375</td><td> 97.778079</td><td>-195.55616</td><td>5.446164e+01</td><td> 16</td><td>4.357935e-06</td></tr>
	<tr><th scope=row>Chao1Lmm19</th><td>203</td><td>110.01007</td><td>859.1530</td><td>147.994963</td><td>-295.98993</td><td>1.004338e+02</td><td> 26</td><td>1.086936e-10</td></tr>
	<tr><th scope=row>Chao1Lmm20</th><td>216</td><td> 96.00274</td><td>893.1204</td><td>167.998628</td><td>-335.99726</td><td>4.000733e+01</td><td> 13</td><td>1.378605e-04</td></tr>
	<tr><th scope=row>Chao1Lmm18</th><td>216</td><td> 96.00274</td><td>893.1204</td><td>167.998628</td><td>-335.99726</td><td>0.000000e+00</td><td>  0</td><td>          NA</td></tr>
	<tr><th scope=row>Chao1Lmm17</th><td>216</td><td> 96.00274</td><td>893.1204</td><td>167.998628</td><td>-335.99726</td><td>0.000000e+00</td><td>  0</td><td>          NA</td></tr>
	<tr><th scope=row>Chao1Lmm16</th><td>216</td><td> 96.00274</td><td>893.1204</td><td>167.998628</td><td>-335.99726</td><td>5.115908e-13</td><td>  0</td><td>          NA</td></tr>
	<tr><th scope=row>Chao1Lmm15</th><td>216</td><td> 96.00274</td><td>893.1204</td><td>167.998628</td><td>-335.99726</td><td>0.000000e+00</td><td>  0</td><td>          NA</td></tr>
	<tr><th scope=row>Chao1Lmm14</th><td>216</td><td> 96.00274</td><td>893.1204</td><td>167.998628</td><td>-335.99726</td><td>0.000000e+00</td><td>  0</td><td>          NA</td></tr>
	<tr><th scope=row>Chao1Lmm13</th><td>216</td><td> 96.00274</td><td>893.1204</td><td>167.998628</td><td>-335.99726</td><td>0.000000e+00</td><td>  0</td><td>          NA</td></tr>
	<tr><th scope=row>Chao1Lmm12</th><td>216</td><td> 96.00274</td><td>893.1204</td><td>167.998628</td><td>-335.99726</td><td>0.000000e+00</td><td>  0</td><td>          NA</td></tr>
</tbody>
</table>



    Warning message in aictab.AIClmerModLmerTest(cand.set = Chao1_models, modnames = Chao1_model.names):
    "
    Check model structure carefully as some models may be redundant
    "
    


<table class="dataframe">
<caption>A aictab: 15 × 8</caption>
<thead>
	<tr><th></th><th scope=col>Modnames</th><th scope=col>K</th><th scope=col>AICc</th><th scope=col>Delta_AICc</th><th scope=col>ModelLik</th><th scope=col>AICcWt</th><th scope=col>LL</th><th scope=col>Cum.Wt</th></tr>
	<tr><th></th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>14</th><td>Chao1Lmm7 </td><td> 22</td><td>  67.17953</td><td>0.000000e+00</td><td> 1.000000e+00</td><td> 4.599756e-01</td><td> -9.736286</td><td>0.4599756</td></tr>
	<tr><th scope=row>10</th><td>Chao1Lmm11</td><td> 22</td><td>  67.17953</td><td>2.557954e-13</td><td> 1.000000e+00</td><td> 4.599756e-01</td><td> -9.736286</td><td>0.9199512</td></tr>
	<tr><th scope=row>15</th><td>Chao1Lmm6 </td><td> 13</td><td>  70.67661</td><td>3.497074e+00</td><td> 1.740283e-01</td><td> 8.004879e-02</td><td>-21.692913</td><td>1.0000000</td></tr>
	<tr><th scope=row>12</th><td>Chao1Lmm9 </td><td>161</td><td> 570.18907</td><td>5.030095e+02</td><td>5.927440e-110</td><td>2.726478e-110</td><td> 70.547258</td><td>1.0000000</td></tr>
	<tr><th scope=row>11</th><td>Chao1Lmm10</td><td>177</td><td> 692.44384</td><td>6.252643e+02</td><td>1.681048e-136</td><td>7.732412e-137</td><td> 97.778079</td><td>1.0000000</td></tr>
	<tr><th scope=row>13</th><td>Chao1Lmm8 </td><td>177</td><td> 692.44384</td><td>6.252643e+02</td><td>1.681048e-136</td><td>7.732412e-137</td><td> 97.778079</td><td>1.0000000</td></tr>
	<tr><th scope=row>2</th><td>Chao1Lmm19</td><td>203</td><td>1010.27094</td><td>9.430914e+02</td><td>1.622938e-205</td><td>7.465120e-206</td><td>147.994963</td><td>1.0000000</td></tr>
	<tr><th scope=row>5</th><td>Chao1Lmm16</td><td>216</td><td>1282.63566</td><td>1.215456e+03</td><td>1.166960e-264</td><td>5.367732e-265</td><td>167.998628</td><td>1.0000000</td></tr>
	<tr><th scope=row>6</th><td>Chao1Lmm15</td><td>216</td><td>1282.63566</td><td>1.215456e+03</td><td>1.166960e-264</td><td>5.367732e-265</td><td>167.998628</td><td>1.0000000</td></tr>
	<tr><th scope=row>7</th><td>Chao1Lmm14</td><td>216</td><td>1282.63566</td><td>1.215456e+03</td><td>1.166960e-264</td><td>5.367732e-265</td><td>167.998628</td><td>1.0000000</td></tr>
	<tr><th scope=row>8</th><td>Chao1Lmm13</td><td>216</td><td>1282.63566</td><td>1.215456e+03</td><td>1.166960e-264</td><td>5.367732e-265</td><td>167.998628</td><td>1.0000000</td></tr>
	<tr><th scope=row>9</th><td>Chao1Lmm12</td><td>216</td><td>1282.63566</td><td>1.215456e+03</td><td>1.166960e-264</td><td>5.367732e-265</td><td>167.998628</td><td>1.0000000</td></tr>
	<tr><th scope=row>1</th><td>Chao1Lmm20</td><td>216</td><td>1282.63566</td><td>1.215456e+03</td><td>1.166960e-264</td><td>5.367732e-265</td><td>167.998628</td><td>1.0000000</td></tr>
	<tr><th scope=row>3</th><td>Chao1Lmm18</td><td>216</td><td>1282.63566</td><td>1.215456e+03</td><td>1.166960e-264</td><td>5.367732e-265</td><td>167.998628</td><td>1.0000000</td></tr>
	<tr><th scope=row>4</th><td>Chao1Lmm17</td><td>216</td><td>1282.63566</td><td>1.215456e+03</td><td>1.166960e-264</td><td>5.367732e-265</td><td>167.998628</td><td>1.0000000</td></tr>
</tbody>
</table>




    
![png](output_20_27.png)
    


## Host-microbiome phylosymbiosis after deleting 7 points 


```R

library(vegan)
library(geosphere)


Gut_BC <-read.table("Gut_BC.txt",header=T,  row.names = 1)
Gut_gd <-read.table("Gut_gd.txt",header=T,  row.names = 1)

Skin_BC <-read.table("Skin_BC.txt",header=T,  row.names = 1)
Skin_gd <-read.table("Skin_gd.txt",header=T,  row.names = 1)




Mantel_gut = mantel(Gut_BC, Gut_gd, method = "pearson", permutations = 9999, na.rm = TRUE)
Mantel_gut
Mantel_Skin = mantel(Skin_BC, Skin_gd, method = "pearson", permutations = 9999, na.rm = TRUE)
Mantel_Skin


Mantel_gut_spearman = mantel(Gut_BC, Gut_gd, method = "spearman", permutations = 9999, na.rm = TRUE)
Mantel_gut_spearman
Mantel_Skin_spearman = mantel(Skin_BC, Skin_gd, method = "spearman", permutations = 9999, na.rm = TRUE)
Mantel_Skin_spearman

```

    The legacy packages maptools, rgdal, and rgeos, underpinning this package
    will retire shortly. Please refer to R-spatial evolution reports on
    https://r-spatial.org/r/2023/05/15/evolution4.html for details.
    This package is now running under evolution status 0 
    
    
    Attaching package: 'geosphere'
    
    
    The following object is masked from 'package:rms':
    
        perimeter
    
    
    


    
    Mantel statistic based on Pearson's product-moment correlation 
    
    Call:
    mantel(xdis = Gut_BC, ydis = Gut_gd, method = "pearson", permutations = 9999,      na.rm = TRUE) 
    
    Mantel statistic r: -0.01432 
          Significance: 0.5413 
    
    Upper quantiles of permutations (null model):
      90%   95% 97.5%   99% 
    0.150 0.198 0.232 0.278 
    Permutation: free
    Number of permutations: 9999
    



    
    Mantel statistic based on Pearson's product-moment correlation 
    
    Call:
    mantel(xdis = Skin_BC, ydis = Skin_gd, method = "pearson", permutations = 9999,      na.rm = TRUE) 
    
    Mantel statistic r: 0.2484 
          Significance: 0.0268 
    
    Upper quantiles of permutations (null model):
      90%   95% 97.5%   99% 
    0.161 0.211 0.253 0.297 
    Permutation: free
    Number of permutations: 9999
    



    
    Mantel statistic based on Spearman's rank correlation rho 
    
    Call:
    mantel(xdis = Gut_BC, ydis = Gut_gd, method = "spearman", permutations = 9999,      na.rm = TRUE) 
    
    Mantel statistic r: -0.03503 
          Significance: 0.6064 
    
    Upper quantiles of permutations (null model):
      90%   95% 97.5%   99% 
    0.153 0.199 0.241 0.283 
    Permutation: free
    Number of permutations: 9999
    



    
    Mantel statistic based on Spearman's rank correlation rho 
    
    Call:
    mantel(xdis = Skin_BC, ydis = Skin_gd, method = "spearman", permutations = 9999,      na.rm = TRUE) 
    
    Mantel statistic r: 0.2229 
          Significance: 0.0409 
    
    Upper quantiles of permutations (null model):
      90%   95% 97.5%   99% 
    0.159 0.211 0.251 0.306 
    Permutation: free
    Number of permutations: 9999
    

